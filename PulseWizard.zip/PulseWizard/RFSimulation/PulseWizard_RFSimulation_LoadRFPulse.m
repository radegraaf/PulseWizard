function [time, RF, freq, phs, grad] = PulseWizard_RFSimulation_LoadRFPulse(handles)

%**************************************************************************
% Function for reading an RF pulse from file.
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************
fileID = fopen(handles.InputFile,'r');

if (fileID < 0)
    % Error dialog if the input file cannot be opened
    errordlg('Input file cannot be opened.','Error');
    
    np = 100;
    RF = zeros(1,np);
    phs = zeros(1,np);
    freq = zeros(1,np);
    grad = zeros(1,np);
    time = 0:handles.PulseLength/(length(RF)-1):handles.PulseLength;
else
    switch handles.InputFileFormat
        case 'PulseWizard'
            % Load RF pulse in PulseWizard format
            datain = fscanf(fileID,'%g %g %g %g',[4 Inf]);
            fclose(fileID);
        
            if (isempty(datain) < 1)
                RF = datain(1,:);
                freq = datain(2,:);
                phs = datain(3,:);
                grad = datain(4,:);      
                time = 0:handles.PulseLength/(length(RF)-1):handles.PulseLength;
            else
                % Condition typically occurs when the incorrect
                % file format is selected.
                np = 100;
                RF = zeros(1,np);
                phs = zeros(1,np);
                freq = zeros(1,np);
                grad = zeros(1,np);
                time = 0:handles.PulseLength/(length(RF)-1):handles.PulseLength;
            end;
            
        case 'Bruker'
            % Load RF pulse in Bruker format
            Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
            CStr = Data{1};
            fclose(fileID);

            % Scanning for ## line starting points
            IndexLSP = strfind(CStr, '##');
            Index = find(cellfun('isempty', IndexLSP));
            
            np = length(Index);
            RF = zeros(1,np);
            phs = zeros(1,np);
            freq = zeros(1,np);
            grad = zeros(1,np);
            
            for DataCounter = 1:np;
                LineRF = char(CStr(Index(DataCounter)));
                IndexComma = strfind(LineRF,',');
                if (isempty(IndexComma) < 1)
                    RFPoint = str2num(LineRF(1:IndexComma-1));
                    if ((isempty(RFPoint) < 1) && (length(RFPoint) == 1))
                        RF(DataCounter) = RFPoint;
                    end;
                    PhasePoint = str2num(LineRF(IndexComma+1:end));
                    if ((isempty(PhasePoint) < 1) && (length(PhasePoint) == 1))
                        phs(DataCounter) = PhasePoint;
                    end;
                end;
            end;
            RF = RF/100;
            
            time = 0:handles.PulseLength/(length(RF)-1):handles.PulseLength;
            
        case 'Varian'
            % Load RF pulse in Varian/Agilent format
            Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
            CStr = Data{1};
            fclose(fileID);

            % Scanning for # line starting points
            IndexLSP = strfind(CStr, '#');
            Index = find(cellfun('isempty', IndexLSP));
            
            np = length(Index);
            RF = zeros(1,np);
            phs = zeros(1,np);
            freq = zeros(1,np);
            grad = zeros(1,np);
            
            for DataCounter = 1:np;
                LineRF = char(CStr(Index(DataCounter)));
                IndexSpace = strfind(LineRF,' ');
                DiffIndexSpace = diff(IndexSpace);
                coor1 = find(DiffIndexSpace > 1);
                switch length(coor1)
                    case 1
                        % No spaces at beginning
                        PhasePoint = str2num(LineRF(1:IndexSpace(1)));
                        if ((isempty(PhasePoint) < 1) && (length(PhasePoint) == 1))
                            phs(DataCounter) = PhasePoint;
                        end;

                        RFPoint = str2num(LineRF(IndexSpace(1):IndexSpace(coor1(1)+1)));
                        if ((isempty(RFPoint) < 1) && (length(RFPoint) == 1))
                            RF(DataCounter) = RFPoint;
                        end;
                 
                    case 2
                        % At least one space at beginning
                        PhasePoint = str2num(LineRF(1:IndexSpace(coor1(1)+1)));
                        if ((isempty(PhasePoint) < 1) && (length(PhasePoint) == 1))
                            phs(DataCounter) = PhasePoint;
                        end;
                        
                        RFPoint = str2num(LineRF(IndexSpace(coor1(1)+1):IndexSpace(coor1(2)+1)));
                        if ((isempty(RFPoint) < 1) && (length(RFPoint) == 1))
                            RF(DataCounter) = RFPoint;
                        end;
                end;
            end;
            RF = RF/1023;
            
            time = 0:handles.PulseLength/(length(RF)-1):handles.PulseLength;
            
        otherwise
            warndlg('This RF pulse file format is not yet implemented.','Warning');
            fclose(fileID);
    end;
    
    if (length(RF) < 2)
        np = 100;
        RF = zeros(1,np);
        phs = zeros(1,np);
        freq = zeros(1,np);
        grad = zeros(1,np);
        time = 0:handles.PulseLength/(length(RF)-1):handles.PulseLength;
    end;
    
    if (max(abs(RF)) == 0)
            warndlg('Zero amplitude RF wave form likely due to incorrect file format.','Warning');
    end;
end;