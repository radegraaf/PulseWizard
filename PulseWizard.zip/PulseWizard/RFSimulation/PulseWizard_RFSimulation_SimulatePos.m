function [PosRange, Mx, My, Mz] = PulseWizard_RFSimulation_SimulatePos(handles)

%**************************************************************************
% Function to start the simulation of magnetization as a function 
% of spatial position.
%
% Notes:
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************

RFamp = handles.RF;
grad = handles.grad;

npRF = length(RFamp);

RFPulseDwellTime = 0.001*(handles.PulseLength/(npRF-1));

% Convert RF pulse phase from degrees to radians
RFphs = (pi/180)*handles.phs;

Mx0 = handles.InitialMagnetization(1);
My0 = handles.InitialMagnetization(2);
Mz0 = handles.InitialMagnetization(3);

PosStep = (handles.PosMax - handles.PosMin)/(handles.NumberOfSimulationPoints-1);
PosRange = handles.PosMin:PosStep:handles.PosMax;

%**************************************************************************
% Scale RF pulse over the entire RF range and convert from kHz to rad/s
%**************************************************************************
RFamp = 2*pi*1000*handles.RFAmplitude*reshape(RFamp,1,[]);

%***********************************************
% Memory allocation
%***********************************************
Mx = zeros(1,handles.NumberOfSimulationPoints);
My = zeros(1,handles.NumberOfSimulationPoints);
Mz = zeros(1,handles.NumberOfSimulationPoints);

Rx = eye(3);
Ry = eye(3); Ry2 = eye(3);
Rz = eye(3); Rz2 = eye(3);

%***********************************************
% Start simulation
%***********************************************
for PosRangeCounter = 1:handles.NumberOfSimulationPoints;   
 
   M(1,1) = Mx0;
   M(2,1) = My0;
   M(3,1) = Mz0; 
      
   for RFPulseCounter = 1:npRF;
       
       SpatialOffset = 2*pi*1000*handles.FrequencyOffset + ...
           2*pi*1000*PosRange(PosRangeCounter)*handles.GradientAmplitude*grad(RFPulseCounter);
       
       term0 = RFamp(RFPulseCounter)^2;
       term1 = SpatialOffset^2;

       Be = sqrt(term0 + term1)*RFPulseDwellTime;
       alpha = atan2(SpatialOffset,RFamp(RFPulseCounter));

       % Precaluclate various sin/cos terms for increased speed
       cosBe = cos(Be); sinBe = sin(Be);
       cosalpha = cos(alpha); sinalpha = sin(alpha);
       cosphi = cos(RFphs(RFPulseCounter)); sinphi = sin(RFphs(RFPulseCounter));

       % Construct the total rotation matrix - Eqs. (5.4)-(5.7) in Chapter 5
       Rx(2,2) = cosBe; Rx(2,3) = sinBe; Rx(3,2) = -1.0*sinBe; Rx(3,3) = cosBe;

       Ry(1,1) = cosalpha; Ry(1,3) = -1.0*sinalpha; Ry(3,1) = sinalpha; Ry(3,3) = cosalpha;
       Ry2(1,1) = cosalpha; Ry2(1,3) = sinalpha; Ry2(3,1) = -1.0*sinalpha; Ry2(3,3) = cosalpha;
       
       Rz(1,1) = cosphi; Rz(1,2) = sinphi; Rz(2,1) = -1.0*sinphi; Rz(2,2) = cosphi;
       Rz2(1,1) = cosphi; Rz2(1,2) = -1.0*sinphi; Rz2(2,1) = sinphi; Rz2(2,2) = cosphi;

       M = Rz*Ry*Rx*Ry2*Rz2*M;
   end;
   
   Mx(PosRangeCounter) = M(1,1);
   My(PosRangeCounter) = M(2,1);
   Mz(PosRangeCounter) = M(3,1);
end;