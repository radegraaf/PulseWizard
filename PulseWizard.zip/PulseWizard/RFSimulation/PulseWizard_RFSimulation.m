function varargout = PulseWizard_RFSimulation(varargin)
% PULSEWIZARD_RFSIMULATION MATLAB code for PulseWizard_RFSimulation.fig
%      PULSEWIZARD_RFSIMULATION, by itself, creates a new PULSEWIZARD_RFSIMULATION or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFSIMULATION returns the handle to a new PULSEWIZARD_RFSIMULATION or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFSIMULATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFSIMULATION.M with the given input arguments.
%
%      PULSEWIZARD_RFSIMULATION('Property','Value',...) creates a new PULSEWIZARD_RFSIMULATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFSimulation_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFSimulation_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFSimulation

% Last Modified by GUIDE v2.5 11-Oct-2016 22:09:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFSimulation_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFSimulation_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard_RFSimulation is made visible.
function PulseWizard_RFSimulation_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFSimulation (see VARARGIN)

% Choose default command line output for PulseWizard_RFSimulation
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .238*ScreenWidth;
FigYPos = .4898*ScreenHeight;
FigWidth = .3712*ScreenWidth;
FigHeight = .4103*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

% Initialize GUI values
Initialize_GUI(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFSimulation_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%**************************************************************************
% Code related to edit box for entering input file name
%**************************************************************************
function InputFile_Edit_Callback(hObject, eventdata, handles)
% Callback for edit box to enter the input RF pulse file. 
% This option is primarily used for generating multi-frequency RF pulses 
% from a base, single-frequency RF pulse.

% Assign updated filename to InputFile
handles.InPutFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)

function InputFile_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box.
% Executes after setting all properties.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Set default pathway
set(hObject,'String',pwd);

% Assign default pathway to InputFile
handles.InPutFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)


%**************************************************************************
% Code related to pulldown menu for selecting input file format
%**************************************************************************
function InputFileFormat_PullDownMenu_Callback(hObject, eventdata, handles)
% Callback for pulldown menu setting the file format of the RF pulse. 

InputFileFormat = cellstr(get(hObject,'String'));
handles.InputFileFormat = InputFileFormat{get(hObject,'Value')};

% Update GUI data structure
guidata(hObject,handles)

function InputFileFormat_PullDownMenu_CreateFcn(hObject, eventdata, handles)
% Creation function, executes after setting all properties.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to push button for selecting input file
%**************************************************************************
function SelectInputFile_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Select Input File button

% Prepare for when Cancel button is pressed
InputFileCancel = handles.InputFile;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select input file',handles.InputFile);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.InputFile = InputFileCancel;
else
    handles.InputFile = [pathname filename];
end;

% Updata GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.InputFile_Edit,'String',handles.InputFile);


%**************************************************************************
% Code related to push button for loading RF pulse
%**************************************************************************
function LoadRFPulse_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Load RF Pulse button

switch handles.InputFileFormat
    case {'PulseWizard','Bruker','Varian'}    
        % Load RF pulse from file
        [time, handles.RF handles.freq handles.phs handles.grad] = PulseWizard_RFSimulation_LoadRFPulse(handles);
              
        % Display RF pulse
        PulseWizard_RFPulse(time,handles.RF,handles.freq,handles.phs,handles.grad);
    case 'GE'
        errordlg('GE Input File Format Is Not Implemented','Error');
    case 'Philips'
        errordlg('Philips Input File Format Is Not Implemented','Error');
    case 'Siemens'
        errordlg('Siemens Input File Format Is Not Implemented','Error');
    otherwise
        errordlg('Select Input File Format Before Loading RF Pulse','Error');
end;

% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated NumberOfPoints to the final, pulse-specific window
SimulationStyle_PullDownMenu_Update(handles)

%**************************************************************************
% Code related to edit box for entering output file name
%**************************************************************************
function OutputFile_Edit_Callback(hObject, eventdata, handles)
% Callback for edit box to enter the output RF pulse file. 

% Assign updated filename to InputFile
handles.OutputFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)


function OutputFile_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box.
% Executes after setting all properties.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Set default pathway
set(hObject,'String',pwd);

% Assign default pathway to OutputFile
handles.OutputFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)


%**************************************************************************
% Code related to pulldown menu for selecting output file format
%**************************************************************************
function OutputFileFormat_PullDownMenu_Callback(hObject, eventdata, handles)
% Function executes on selection change in OutputFileFormat pulldown menu.

OutputFileFormat = cellstr(get(hObject,'String'));
handles.OutputFileFormat = OutputFileFormat{get(hObject,'Value')};

% Update GUI data structure
hObject = findall(0,'Name','PulseWizard_RFSimulation');
guidata(hObject,handles)

function OutputFileFormat_PullDownMenu_CreateFcn(hObject, eventdata, handles)
% Creation function, executes after setting all properties.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to push button for selecting output file
%**************************************************************************
function SelectOutputFile_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Select Output File button

% Prepare for when Cancel button is pressed
OutputFileCancel = handles.OutputFile;

% Get new file and path names
[filename, pathname] = uiputfile('*.*','Select output file',handles.OutputFile);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.OutputFile = OutputFileCancel;
else
    handles.OutputFile = [pathname filename];
end;

% Updata GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new output filename
set(handles.OutputFile_Edit,'String',handles.OutputFile);


%**************************************************************************
% Code related to push button for saving simulation results
%**************************************************************************
function SaveResults_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Save RF Pulse button

PulseWizard_RFSimulation_SaveResults(handles);


%**************************************************************************
% Code related to edit box for number of points in RF pulse
%**************************************************************************
function NumberOfSimulationPoints_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for NumberOfPoints
handles.NumberOfSimulationPoints = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.NumberOfSimulationPoints) > 0) || (isinf(handles.NumberOfSimulationPoints) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of points.'];
    ErrorMessage2 = ['Error: Number of points set to valid default value (200).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.NumberOfSimulationPoints = 200;
    set(hObject,'String',handles.NumberOfSimulationPoints);
end;

% Only allow positive integer numbers
if (rem(handles.NumberOfSimulationPoints,1) ~= 0)
    ErrorMessage1 = ['Error: Invalid entry (' num2str(handles.NumberOfSimulationPoints) ') for number of points.'];
    ErrorMessage2 = ['Error: Number of points set to valid default value (' num2str(abs(round(handles.NumberOfSimulationPoints))) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');    
    
    handles.NumberOfSimulationPoints = abs(round(handles.NumberOfSimulationPoints));
    set(hObject,'String',handles.NumberOfSimulationPoints);
end;

% Enforce a minimum of 2 points
if (handles.NumberOfSimulationPoints < 2)
    ErrorMessage1 = ['Error: Invalid entry (' num2str(handles.NumberOfSimulationPoints) ') for number of points.'];
    ErrorMessage2 = ['Error: Number of points set to valid default value (2).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' '); 
    
    handles.NumberOfSimulationPoints = 2;
    set(hObject,'String',handles.NumberOfSimulationPoints);
end;

% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated NumberOfPoints to the final, pulse-specific window
SimulationStyle_PullDownMenu_Update(handles)

function NumberOfSimulationPoints_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for RF pulselength
%**************************************************************************
function PulseLength_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for PulseLength
handles.PulseLength = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.PulseLength) > 0) || (isinf(handles.PulseLength) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for pulse length.'];
    ErrorMessage2 = ['Error: Pulse length set to valid default value (5.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.PulseLength = 5.0;
    set(hObject,'String',handles.PulseLength);
end;

% Only allow positive pulse lengths
if (handles.PulseLength < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for pulse length.'];
    ErrorMessage2 = ['Error: Pulse length set to valid default value (' num2str(abs(handles.PulseLength)) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.PulseLength = abs(handles.PulseLength);
    set(hObject,'String',handles.PulseLength);
end;

if (handles.PulseLength == 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for pulse length.'];
    ErrorMessage2 = ['Error: Pulse length set to valid default value (0.001).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.PulseLength = 1e-3;
    set(hObject,'String',handles.PulseLength);
end;

% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated PulseLength to the final, pulse-specific window
SimulationStyle_PullDownMenu_Update(handles)

function PulseLength_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
    

%**************************************************************************
% Code related to edit box for initial magnetization (Mx, My, Mz)
%**************************************************************************
function InitialMagnetization_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for InitialPhase
handles.InitialMagnetization = str2num(get(hObject,'String'));

% Check for invalid entry
if (isempty(handles.InitialMagnetization) > 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for initial magnetization.'];
    ErrorMessage2 = ['Error: Initial magnetization set to valid default value (0, 0, 1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.InitialMagnetization = [0 0 1];
    set(hObject,'String','0, 0, 1');
end;

% Enforce the input to have 3 numerical values
if (length(handles.InitialMagnetization) ~= 3)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for initial magnetization.'];
    ErrorMessage2 = ['Error: Initial magnetization set to valid default value (0, 0, 1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.InitialMagnetization = [0 0 1];
    set(hObject,'String','0, 0, 1');
end;

Mx = handles.InitialMagnetization(1);
My = handles.InitialMagnetization(2);
Mz = handles.InitialMagnetization(3);

% Enforce the total magnetization to be equal or smaller than 1.0
if (sqrt(Mx*Mx + My*My + Mz*Mz) > 1.0)   
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for initial magnetization.'];
    ErrorMessage2 = ['Error: Total magnetization should be equal to or less than 1.0.'];
    ErrorMessage3 = ['Error: Initial magnetization set to valid default value (0, 0, 1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(ErrorMessage3); disp(' ');
    
    handles.InitialMagnetization = [0 0 1];
    set(hObject,'String','0, 0, 1');
end;
    
% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated InitialPhase to the final, pulse-specific window
SimulationStyle_PullDownMenu_Update(handles)

function InitialMagnetization_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to pulldown menu to select simulation style
%**************************************************************************
function SimulationStyle_PullDownMenu_Callback(hObject, eventdata, handles)
% Function executes when selecting a new RF pulse family
SimulationStyle = cellstr(get(hObject,'String'));
handles.SimulationStyleSelected = SimulationStyle{get(hObject,'Value')};

if (max(abs(handles.RF)) > 0)

    % Parameters to be transferred to next RF generation subprogram
    varargin{1} = [handles.NumberOfSimulationPoints handles.PulseLength];
    varargin{2} = handles.InitialMagnetization;
    varargin{3} = handles.RF;
    varargin{4} = handles.phs;
    varargin{5} = handles.grad;
    varargin{6} = 'Yes';    % Initialize next window

    % Upon pulldown selection, open a new window with
    % parameter entries specific for the new RF pulse family.
    switch handles.SimulationStyleSelected
        case 'RF amplitude'
            
            % Close windows from previous simulations
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Freq');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Pos');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Time');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            % If the pulse specific window does not exist, initialize
            % parameters. Otherwise, skip initialization.
            hh = findall(0,'Name','PulseWizard_RFSimulation_RF');
            if (isempty(hh) > 0)
                PulseWizard_RFSimulation_RF(varargin);
            else
                varargin{6} = 'No';     % Do not initialize next window
                PulseWizard_RFSimulation_RF(varargin);
            end;
        case 'Frequency offset'

            % Close windows from previous simulations
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_RF');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Pos');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Time');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            % If the pulse specific window does not exist, initialize
            % parameters. Otherwise, skip initialization.
            hh = findall(0,'Name','PulseWizard_RFSimulation_Freq');
            if (isempty(hh) > 0)
                PulseWizard_RFSimulation_Freq(varargin);
            else
                varargin{6} = 'No';     % Do not initialize next window
                PulseWizard_RFSimulation_Freq(varargin);
            end;
        case 'Position'
            
            % Close windows from previous simulations
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_RF');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Freq');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Time');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;

            % If the pulse specific window does not exist, initialize
            % parameters. Otherwise, skip initialization.
            hh = findall(0,'Name','PulseWizard_RFSimulation_Pos');
            if (isempty(hh) > 0)
                PulseWizard_RFSimulation_Pos(varargin);
            else
                varargin{6} = 'No';     % Do not initialize next window
                PulseWizard_RFSimulation_Pos(varargin);
            end;
        case 'Time'

            % Close windows from previous simulations
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_RF');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Freq');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Pos');
            if (isempty(hObject1) < 1)
                delete(hObject1);
            end;
            
            % If the pulse specific window does not exist, initialize
            % parameters. Otherwise, skip initialization.
            hh = findall(0,'Name','PulseWizard_RFSimulation_Time');
            if (isempty(hh) > 0)
                PulseWizard_RFSimulation_Time(varargin);
            else
                varargin{6} = 'No';     % Do not initialize next window
                PulseWizard_RFSimulation_Time(varargin);
            end;
    end;
    
else
    errordlg({'      No valid RF pulse available for simulation.',' ',...
    'First load RF pulse before attempting to start simulation'},'Error');

    handles.SimulationStyleSelected = 'Simulation Style';
    set(handles.SimulationStyle_PullDownMenu,'Value',1);
end;

% Update GUI data structure
guidata(hObject, handles);

function SimulationStyle_PullDownMenu_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SimulationStyle_PullDownMenu_Update(handles)
% Function executes on new parameter entries in the general
% RF generation window to ensure that those new entries are 
% transferred to the RF pulse specific parameter window.

% Parameters to be transferred to next RF generation subprogram
varargin{1} = [handles.NumberOfSimulationPoints handles.PulseLength];
varargin{2} = handles.InitialMagnetization;
varargin{3} = handles.RF;
varargin{4} = handles.phs;
varargin{5} = handles.grad;
varargin{6} = 'No';    % Do not initialize next window
 
switch handles.SimulationStyleSelected
    case 'RF amplitude'
        PulseWizard_RFSimulation_RF(varargin);
    case 'Frequency offset'
        PulseWizard_RFSimulation_Freq(varargin);
    case 'Position'
        PulseWizard_RFSimulation_Pos(varargin);
    case 'Time'
        PulseWizard_RFSimulation_Time(varargin);
end;

%**************************************************************************
% Code related to GUI/handles parameter initialization
%**************************************************************************
function Initialize_GUI(hObject, handles)

handles.InputFileFormat = 'Input File Format';
handles.InputFile = pwd;
handles.OutputFileFormat = 'Output File Format';
handles.OutputFile = pwd;
handles.SimulationStyleSelected = 'Simulation Style';
handles.NumberOfSimulationPoints = 200;
handles.PulseLength = 5.0;
handles.InitialMagnetization = str2num('0, 0, 1');
handles.RF = [0 0];
handles.phs = [0 0];
handles.grad = [0 0];

% Update GUI data structure
guidata(hObject, handles);


% --- Executes on button press in HelpManual_PushButton.
function HelpManual_PushButton_Callback(hObject, eventdata, handles)
% hObject    handle to HelpManual_PushButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

HelpFile = [pwd '\PulseWizard_Manual.pdf'];

[~, result] = system(HelpFile);

if (isempty(result) < 1)
    errordlg({'     PulseWizard Manual Could Not Be Opened.',' ',...
        'Manual PDF File Is Located In PulseWizard Directory'},'File Error');
end;
