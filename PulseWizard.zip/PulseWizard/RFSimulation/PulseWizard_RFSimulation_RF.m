function varargout = PulseWizard_RFSimulation_RF(varargin)

% PULSEWIZARD_RFSIMULATION_RF MATLAB code for PulseWizard_RFSimulation_RF.fig
%      PULSEWIZARD_RFSIMULATION_RF, by itself, creates a new PULSEWIZARD_RFSIMULATION_RF or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFSIMULATION_RF returns the handle to a new PULSEWIZARD_RFSIMULATION_RF or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFSIMULATION_RF('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFSIMULATION_RF.M with the given input arguments.
%
%      PULSEWIZARD_RFSIMULATION_RF('Property','Value',...) creates a new PULSEWIZARD_RFSIMULATION_RF or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFSimulation_RF_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFSimulation_RF_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFSimulation_RF

% Last Modified by GUIDE v2.5 18-Jul-2018 15:51:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFSimulation_RF_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFSimulation_RF_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard_RFSimulation_RF is made visible.
function PulseWizard_RFSimulation_RF_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFSimulation_RF (see VARARGIN)

% Choose default command line output for PulseWizard_RFSimulation_RF
handles.output = hObject;

TransferredParameters = varargin{1};
NumericalParameters = TransferredParameters{1};
StringParameters = TransferredParameters{2};
ArrayParameters1 = TransferredParameters{3};
ArrayParameters2 = TransferredParameters{4};
ArrayParameters3 = TransferredParameters{5};
InitializeParameters = TransferredParameters{6};

handles.NumberOfSimulationPoints = NumericalParameters(1);
handles.PulseLength = NumericalParameters(2);
handles.RF = ArrayParameters1;
handles.phs = ArrayParameters2;
handles.grad = ArrayParameters3;

handles.InitialMagnetization = StringParameters;
handles.Initialize = InitializeParameters;

% Update handles structure
guidata(hObject, handles);

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .238*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .3712*ScreenWidth;
FigHeight = .225*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

if (strcmp(handles.Initialize,'Yes') > 0)
    % Initialize GUI values
    Initialize_GUI(hObject, handles);
end;


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFSimulation_RF_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%**************************************************************************
% Code related to edit box for minimum RF amplitude
%**************************************************************************
function RFMin_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for minimum RF amplitude
handles.RFMin = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.RFMin) > 0) || (isinf(handles.RFMin) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for minimum RF amplitude.'];
    ErrorMessage2 = ['Error: Minimum RF amplitude set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.RFMin = 0.0;
    set(hObject,'String',handles.RFMin);
end;

% Only allow positive values
if (handles.RFMin < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for minimum RF amplitude.'];
    ErrorMessage2 = ['Error: Minimum RF amplitude set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.RFMin = 0.0;
    set(hObject,'String',handles.RFMin);
end;

% Do not allow RFmin > RFmax
if (handles.RFMin > handles.RFMax)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for minimum RF amplitude.'];
    ErrorMessage2 = ['Error: Minimum RF amplitude set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.RFMin = 0.0;
    set(hObject,'String',handles.RFMin);
end;

% Updata GUI data structure
guidata(hObject,handles)

function RFMin_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for bandwidth edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for maximum RF amplitude
%**************************************************************************
function RFMax_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for RFConstant1
handles = guidata(hObject);
handles.RFMax = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.RFMax) > 0) || (isinf(handles.RFMax) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for maximum RF amplitude.'];
    ErrorMessage2 = ['Error: Maximum RF amplitude set to valid default value (' num2str(handles.RFMin + 1.0) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.RFMax = handles.RFMin + 1.0;
    set(hObject,'String',handles.RFMax);
end;

% Do not allow RFmax <= RFmin
if (handles.RFMax <= handles.RFMin)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for maximum RF amplitude.'];
    ErrorMessage2 = ['Error: Maximum RF amplitude set to valid default value (' num2str(handles.RFMin + 1.0) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.RFMax = handles.RFMin + 1.0;
    set(hObject,'String',handles.RFMax);
end;

% Updata GUI data structure
guidata(hObject,handles)

function RFMax_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for RFConstant1 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for frequency offset (kHz)
%**************************************************************************
function FrequencyOffset_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for RFConstant2
handles = guidata(hObject);
handles.FrequencyOffset = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FrequencyOffset) > 0) || (isinf(handles.FrequencyOffset) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for frequency offset.'];
    ErrorMessage2 = ['Error: Frequency offset set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FrequencyOffset = 0.0;
    set(hObject,'String',handles.FrequencyOffset);
end;

% Updata GUI data structure
guidata(hObject,handles)

function FrequencyOffset_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for RFConstant2 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to push button for start RF Pulse Simulation
%**************************************************************************
function SimulateRF_PushButton_Callback(hObject, eventdata, handles)
% Function executes when pushing the Generate RF Pulse button

% Perform simulation
[RFrange, Mx, My, Mz] = PulseWizard_RFSimulation_SimulateRF(handles);

% Close windows from previous simulations
hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_RF');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Freq');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_Freq');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Pos');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_Pos');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Time');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

% Display simulation results
PulseWizard_RFSimulation_Results_M_RF(RFrange, Mx, My, Mz);
        
% Calculated simulation results must be transferred to main
% simulation window for saving purposes.
% 1. Retrieve GUI data structure from main RF simulation window
hObject = findall(0,'Name','PulseWizard_RFSimulation');
handles = guidata(hObject);

% Remove field related to refocused component.
% Necessary for saving purposes.
if (isfield(handles,'RC') > 0)
    handles = rmfield(handles,'RC');
    handles = rmfield(handles,'RCphs');
end;

% 2. Add simulation attributes to handles
handles.RFrange = RFrange;
handles.Mx = Mx;
handles.My = My;
handles.Mz = Mz;

% 3. Updata GUI data structure in main RF simulation window
guidata(hObject,handles)



%**************************************************************************
% Code related to GUI/handles parameter initialization
%**************************************************************************
function Initialize_GUI(hObject, handles)

handles.RFMin = 0.0;
handles.RFMax = 5.0;
handles.FrequencyOffset = 0.0;

% Update GUI data structure
guidata(hObject, handles);


%*************************************************************************************
% Code related to push button for start RF Pulse Refocused Component (RC) Simulation
%*************************************************************************************
function SimulateRF_RC_PushButton_Callback(hObject, eventdata, handles)
% Function executes when pushing the Generate RF Pulse button

% Perform simulation
[RFrange, RC, RCphs] = PulseWizard_RFSimulation_SimulateRCRF(handles);

% Close windows from previous simulations
hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_M_RF');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Freq');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_Freq');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Pos');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_Pos');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

hObject1 = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Time');
if (isempty(hObject1) < 1)
    delete(hObject1);
end;

% Display simulation results
PulseWizard_RFSimulation_Results_RC_RF(RFrange, RC, RCphs);
        
% Calculated simulation results must be transferred to main
% simulation window for saving purposes.
% 1. Retrieve GUI data structure from main RF simulation window
hObject = findall(0,'Name','PulseWizard_RFSimulation');
handles = guidata(hObject);

% Remove field related to Mxyz magnetization.
% Necessary for saving purposes.
if (isfield(handles,'Mx') > 0)
    handles = rmfield(handles,'Mx');
    handles = rmfield(handles,'My');
    handles = rmfield(handles,'Mz');
end;

% 2. Add simulation attributes to handles
handles.RFrange = RFrange;
handles.RC = RC;
handles.RCphs = RCphs;

% 3. Updata GUI data structure in main RF simulation window
guidata(hObject,handles)
