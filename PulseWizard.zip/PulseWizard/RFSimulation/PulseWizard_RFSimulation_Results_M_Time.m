function varargout = PulseWizard_RFSimulation_Results_M_Time(varargin)
% PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME MATLAB code for PulseWizard_RFSimulation_Results_M_Time.fig
%      PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME, by itself, creates a new PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME returns the handle to a new PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME.M with the given input arguments.
%
%      PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME('Property','Value',...) creates a new PULSEWIZARD_RFSIMULATION_RESULTS_M_TIME or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFSimulation_Results_M_Time_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFSimulation_Results_M_Time_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFSimulation_Results_M_Time

% Last Modified by GUIDE v2.5 01-Apr-2017 21:51:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFSimulation_Results_M_Time_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFSimulation_Results_M_Time_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT

% --- Executes just before PulseWizard_RFSimulation_Results_M_Time is made visible.
function PulseWizard_RFSimulation_Results_M_Time_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFSimulation_Results_M_Time (see VARARGIN)

% Choose default command line output for PulseWizard_RFSimulation_Results_M_Time
handles.output = hObject;

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .613*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .362*ScreenWidth;
FigHeight = .64235*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

% Update handles structure
guidata(hObject, handles);

Time = varargin{1};
Mx = varargin{2};
My = varargin{3};
Mz = varargin{4};

axes(handles.axes1);
plot(Time,Mx,'b',Time,My,'r')
axis([0 max(Time) -1 1]);
xlabel('Time (ms)');
ylabel('Mx,y/M0');
grid on;

axes(handles.axes2);
plot(Time,Mz,'b')
axis([0 max(Time) -1 1]);
xlabel('Time (ms)');
ylabel('Mz/M0');
grid on;

[x3D, y3D, z3D] = sphere(18);

axes(handles.axes3);
colormap('white');
surf(x3D,y3D,z3D);
axis([-1 1 -1 1 -1 1]);
xlabel('Mx'); ylabel('My'); zlabel('Mz');
hold on;
ah = plot3(Mx,My,Mz);
set(ah,'LineWidth',2.0,'Color',[0 0 0]);
hold off;

% UIWAIT makes PulseWizard_RFSimulation_Results_M_Time wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFSimulation_Results_M_Time_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
