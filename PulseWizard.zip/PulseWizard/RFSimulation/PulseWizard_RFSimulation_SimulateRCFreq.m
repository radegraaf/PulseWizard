function [FreqRange, RC, RCphs] = PulseWizard_RFSimulation_SimulateRCFreq(handles)

%**************************************************************************
% Function to start the simulation of the refocused component as a function 
% of frequency offset.
%
% Notes:
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************

RFamp = handles.RF;
npRF = length(RFamp);

RFPulseDwellTime = 0.001*(handles.PulseLength/(npRF-1));

% Convert RF pulse phase from degrees to radians
RFphs = (pi/180)*handles.phs;

Mx0array = [1.0 0.0];
My0array = [0.0 1.0];
Mz0array = [0.0 0.0];

FreqStep = (handles.FreqMax - handles.FreqMin)/(handles.NumberOfSimulationPoints-1);
FreqRange = handles.FreqMin:FreqStep:handles.FreqMax;

%**************************************************************************
% Scale RF pulse over the entire RF range and convert from kHz to rad/s
%**************************************************************************
RFamp = 2*pi*1000*handles.RFAmplitude*reshape(RFamp,1,[]);

%***********************************************
% Memory allocation
%***********************************************
Mx = zeros(2,handles.NumberOfSimulationPoints);
My = zeros(2,handles.NumberOfSimulationPoints);

%***********************************************
% Start simulation
%***********************************************
for RCCounter = 1:2;
    
    Mx0 = Mx0array(RCCounter);
    My0 = My0array(RCCounter);
    Mz0 = Mz0array(RCCounter);
    
    for FreqRangeCounter = 1:handles.NumberOfSimulationPoints;   

       M(1,1) = Mx0;
       M(2,1) = My0;
       M(3,1) = Mz0;

       R = eye(3);

       %***************************************************
       % Convert frequency offset from kHz to rad/s
       %***************************************************
       RFoffset = 2*pi*1000*FreqRange(FreqRangeCounter);

       for RFPulseCounter = 1:npRF;

           term0 = RFamp(RFPulseCounter)^2;
           term1 = RFoffset^2;

           Be = sqrt(term0 + term1)*RFPulseDwellTime;
           alpha = atan2(RFoffset,RFamp(RFPulseCounter));

           cosBe = cos(Be);
           sinBe = sin(Be);

           cos1alpha = cos(alpha);
           cos2alpha = cos(alpha)*cos(alpha);
           sin1alpha = sin(alpha);
           sin2alpha = sin(alpha)*sin(alpha);

           cos1phi = cos(RFphs(RFPulseCounter));
           cos2phi = cos(RFphs(RFPulseCounter))*cos(RFphs(RFPulseCounter));
           sin1phi = sin(RFphs(RFPulseCounter));
           sin2phi = sin(RFphs(RFPulseCounter))*sin(RFphs(RFPulseCounter));

           % Construct the total rotation matrix - Eqs. (5.4)-(5.7) in Chapter 5
           R(1,1) = cos2phi*(cos2alpha + cosBe*sin2alpha) + cosBe*sin2phi;
           R(2,1) = -sin1alpha*sinBe + sin1phi*cos1phi*cos2alpha*(1 - cosBe);
           R(3,1) = cos1alpha*(cos1phi*sin1alpha*(cosBe - 1) - sinBe*sin1phi);

           R(1,2) = sin1alpha*sinBe + sin1phi*cos1phi*cos2alpha*(1 - cosBe);
           R(2,2) = cosBe*cos2phi + (cos2alpha + cosBe*sin2alpha)*sin2phi;
           R(3,2) = sin1alpha*cos1alpha*sin1phi*(cosBe - 1) + cos1alpha*cos1phi*sinBe;

           R(1,3) = cos1alpha*(cos1phi*sin1alpha*(cosBe - 1) + sinBe*sin1phi);
           R(2,3) = sin1alpha*cos1alpha*sin1phi*(cosBe - 1) - cos1alpha*cos1phi*sinBe;
           R(3,3) = cosBe*cos2alpha + sin2alpha;

           M = R*M;

       end;

       Mx(RCCounter,FreqRangeCounter) = M(1,1);
       My(RCCounter,FreqRangeCounter) = M(2,1);
    end;
end;

% Extract refocused component from simulated Mx and My
RC = 0.5*sqrt((Mx(1,:) - My(2,:)).^2 + (Mx(2,:) + My(1,:)).^2);
RCphs = (180/pi)*atan2((Mx(2,:) + My(1,:)),(My(2,:) - Mx(1,:)));