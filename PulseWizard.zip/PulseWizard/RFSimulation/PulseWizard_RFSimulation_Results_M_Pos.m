function varargout = PulseWizard_RFSimulation_Results_M_Pos(varargin)
% PULSEWIZARD_RFSIMULATION_RESULTS_M_POS MATLAB code for PulseWizard_RFSimulation_Results_M_Pos.fig
%      PULSEWIZARD_RFSIMULATION_RESULTS_M_POS, by itself, creates a new PULSEWIZARD_RFSIMULATION_RESULTS_M_POS or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFSIMULATION_RESULTS_M_POS returns the handle to a new PULSEWIZARD_RFSIMULATION_RESULTS_M_POS or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFSIMULATION_RESULTS_M_POS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFSIMULATION_RESULTS_M_POS.M with the given input arguments.
%
%      PULSEWIZARD_RFSIMULATION_RESULTS_M_POS('Property','Value',...) creates a new PULSEWIZARD_RFSIMULATION_RESULTS_M_POS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFSimulation_Results_M_Pos_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFSimulation_Results_M_Pos_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFSimulation_Results_M_Pos

% Last Modified by GUIDE v2.5 02-Apr-2017 11:36:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFSimulation_Results_M_Pos_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFSimulation_Results_M_Pos_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT

% --- Executes just before PulseWizard_RFSimulation_Results_M_Pos is made visible.
function PulseWizard_RFSimulation_Results_M_Pos_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFSimulation_Results_M_Pos (see VARARGIN)

% Choose default command line output for PulseWizard_RFSimulation_Results_M_Pos
handles.output = hObject;

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .613*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .362*ScreenWidth;
FigHeight = .64235*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

% Update handles structure
guidata(hObject, handles);

PosRange = varargin{1};
Mx = varargin{2};
My = varargin{3};
Mz = varargin{4};
Mxy = sqrt(Mx.^2 + My.^2);

axes(handles.axes1);
plot(PosRange,Mx)
axis([min(PosRange) max(PosRange) -1 1]);
xlabel('Position (cm)');
ylabel('Mx/M0');
grid on;

axes(handles.axes2);
plot(PosRange,My)
axis([min(PosRange) max(PosRange) -1 1]);
xlabel('Position (cm)');
ylabel('My/M0');
grid on;

axes(handles.axes3);
plot(PosRange,Mz)
axis([min(PosRange) max(PosRange) -1 1]);
xlabel('Position (cm)');
ylabel('Mz/M0');
grid on;

axes(handles.axes4);
plot(PosRange,Mxy)
axis([min(PosRange) max(PosRange) 0 1]);
xlabel('Position (cm)');
ylabel('Mxy/M0');
grid on;

% UIWAIT makes PulseWizard_RFSimulation_Results_M_Pos wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFSimulation_Results_M_Pos_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
