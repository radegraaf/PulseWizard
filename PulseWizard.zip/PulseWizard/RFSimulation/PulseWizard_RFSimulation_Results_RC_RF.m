function varargout = PulseWizard_RFSimulation_Results_RC_RF(varargin)
% PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF MATLAB code for PulseWizard_RFSimulation_Results_RC_RF.fig
%      PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF, by itself, creates a new PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF returns the handle to a new PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF.M with the given input arguments.
%
%      PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF('Property','Value',...) creates a new PULSEWIZARD_RFSIMULATION_RESULTS_RC_RF or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFSimulation_Results_RC_RF_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFSimulation_Results_RC_RF_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFSimulation_Results_RC_RF

% Last Modified by GUIDE v2.5 29-Mar-2017 12:21:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFSimulation_Results_RC_RF_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFSimulation_Results_RC_RF_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT

% --- Executes just before PulseWizard_RFSimulation_Results_RC_RF is made visible.
function PulseWizard_RFSimulation_Results_RC_RF_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFSimulation_Results_RC_RF (see VARARGIN)

% Choose default command line output for PulseWizard_RFSimulation_Results_RC_RF
handles.output = hObject;

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .613*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .362*ScreenWidth;
FigHeight = .64235*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

% Update handles structure
guidata(hObject, handles);

RFrange = varargin{1};
RC = varargin{2};
RCphs = varargin{3};

axes(handles.axes1);
plot(RFrange,RC)
axis([min(RFrange) max(RFrange) 0 1]);
xlabel('Frequency (kHz)');
ylabel('Refocused component, RC');
grid on;

axes(handles.axes2);
plot(RFrange,RCphs)
axis([min(RFrange) max(RFrange) min(RCphs) max(RCphs)]);
xlabel('Frequency (kHz)');
ylabel('RC phase (deg)');
grid on;

axes(handles.axes3);
plot(RFrange,RC.*cosd(RCphs))
axis([min(RFrange) max(RFrange) -1 1]);
xlabel('Frequency (kHz)');
ylabel('Real RC');
grid on;

axes(handles.axes4);
plot(RFrange,RC.*sind(RCphs))
axis([min(RFrange) max(RFrange) -1 1]);
xlabel('Frequency (kHz)');
ylabel('Imaginary RC');
grid on;

% UIWAIT makes PulseWizard_RFSimulation_Results_RC_RF wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFSimulation_Results_RC_RF_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
