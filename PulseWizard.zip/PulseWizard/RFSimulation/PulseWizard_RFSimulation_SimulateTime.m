function [Time, Mx, My, Mz] = PulseWizard_RFSimulation_SimulateTime(handles)

%**************************************************************************
% Function to start the simulation of magnetization as a function 
% of time.
%
% Notes:
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************

RFamp = handles.RF;
npRF = length(RFamp);

RFPulseDwellTime = 0.001*(handles.PulseLength/(npRF-1));
Time = 0:handles.PulseLength/(npRF-1):handles.PulseLength;

% Convert RF pulse phase from degrees to radians
RFphs = (pi/180)*handles.phs;

Mx0 = handles.InitialMagnetization(1);
My0 = handles.InitialMagnetization(2);
Mz0 = handles.InitialMagnetization(3);

%**************************************************************************
% Scale RF pulse over the entire RF range and convert from kHz to rad/s
%**************************************************************************
RFamp = 2*pi*1000*handles.RFAmplitude*reshape(RFamp,1,[]);

%***********************************************
% Memory allocation
%***********************************************
Mx = zeros(1,npRF);
My = zeros(1,npRF);
Mz = zeros(1,npRF);

Rx = eye(3);
Ry = eye(3); Ry2 = eye(3);
Rz = eye(3); Rz2 = eye(3);

%***********************************************
% Start simulation
%***********************************************
M(1,1) = Mx0;
M(2,1) = My0;
M(3,1) = Mz0;

%***************************************************
% Convert frequency offset from kHz to rad/s
%***************************************************
RFoffset = 2*pi*1000*handles.FrequencyOffset;

for RFPulseCounter = 1:npRF;

   term0 = RFamp(RFPulseCounter)^2;
   term1 = RFoffset^2;

   Be = sqrt(term0 + term1)*RFPulseDwellTime;
   alpha = atan2(RFoffset,RFamp(RFPulseCounter));

   % Precaluclate various sin/cos terms for increased speed
   cosBe = cos(Be); sinBe = sin(Be);
   cosalpha = cos(alpha); sinalpha = sin(alpha);
   cosphi = cos(RFphs(RFPulseCounter)); sinphi = sin(RFphs(RFPulseCounter));

   % Construct the total rotation matrix - Eqs. (5.4)-(5.7) in Chapter 5
   Rx(2,2) = cosBe; Rx(2,3) = sinBe; Rx(3,2) = -1.0*sinBe; Rx(3,3) = cosBe;

   Ry(1,1) = cosalpha; Ry(1,3) = -1.0*sinalpha; Ry(3,1) = sinalpha; Ry(3,3) = cosalpha;
   Ry2(1,1) = cosalpha; Ry2(1,3) = sinalpha; Ry2(3,1) = -1.0*sinalpha; Ry2(3,3) = cosalpha;

   Rz(1,1) = cosphi; Rz(1,2) = sinphi; Rz(2,1) = -1.0*sinphi; Rz(2,2) = cosphi;
   Rz2(1,1) = cosphi; Rz2(1,2) = -1.0*sinphi; Rz2(2,1) = sinphi; Rz2(2,2) = cosphi;

   M = Rz*Ry*Rx*Ry2*Rz2*M;
   
   Mx(RFPulseCounter) = M(1,1);
   My(RFPulseCounter) = M(2,1);
   Mz(RFPulseCounter) = M(3,1);
end;