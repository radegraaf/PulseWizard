function PulseWizard_RFSimulation_SaveResults(handles)

%**************************************************************************
% Function to save simulation results to disk.
%
% Notes:
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************

switch handles.SimulationStyleSelected
    case 'RF amplitude'
        if (isfield(handles,'RC') > 0)
            % Simulation results are focused on refocused component
            TitleArray.Column{1} = 'RF amplitude (kHz)';
            TitleArray.Column{2} = 'Mx/M0';
            TitleArray.Column{3} = 'My/M0';
            TitleArray.Column{4} = 'Mz/M0';
            TitleArray.Column{5} = 'Mxy/M0';
            
            ResultMatrix = [reshape(handles.RFrange,1,[]); reshape(handles.RC,1,[]); ...
                reshape(handles.RCphs,1,[]); reshape((handles.RC).*cosd(handles.RCphs),1,[]); ...
                reshape((handles.RC).*sind(handles.RCphs),1,[])];            
        else
            % Simulation results are focused on magnetization components
            TitleArray.Column{1} = 'Frequency (kHz)';
            TitleArray.Column{2} = 'RC';
            TitleArray.Column{3} = 'RC phase (deg)';
            TitleArray.Column{4} = 'real RC';
            TitleArray.Column{5} = 'imag RC';
            
            ResultMatrix = [reshape(handles.RFrange,1,[]); reshape(handles.Mx,1,[]); ...
                reshape(handles.My,1,[]); reshape(handles.Mz,1,[]); ...
                reshape(sqrt((handles.Mx).*handles.Mx+(handles.My).*handles.My),1,[])];
        end;
        
    case 'Frequency offset'
        if (isfield(handles,'RC') > 0)
            % Simulation results are focused on refocused component
            TitleArray.Column{1} = 'Frequency (kHz)';
            TitleArray.Column{2} = 'RC';
            TitleArray.Column{3} = 'RC phase (deg)';
            TitleArray.Column{4} = 'real RC';
            TitleArray.Column{5} = 'imag RC';
            
            ResultMatrix = [reshape(handles.FreqRange,1,[]); reshape(handles.RC,1,[]); ...
                reshape(handles.RCphs,1,[]); reshape((handles.RC).*cosd(handles.RCphs),1,[]); ...
                reshape((handles.RC).*sind(handles.RCphs),1,[])];            
        else
            % Simulation results are focused on magnetization components
            TitleArray.Column{1} = 'Frequency (kHz)';
            TitleArray.Column{2} = 'Mx/M0';
            TitleArray.Column{3} = 'My/M0';
            TitleArray.Column{4} = 'Mz/M0';
            TitleArray.Column{5} = 'Mxy/M0';
            
            ResultMatrix = [reshape(handles.FreqRange,1,[]); reshape(handles.Mx,1,[]); ...
                reshape(handles.My,1,[]); reshape(handles.Mz,1,[]); ...
                reshape(sqrt((handles.Mx).*handles.Mx+(handles.My).*handles.My),1,[])];
        end;
        
    case 'Position'
        
    case 'Time'
            % Simulation results are focused on magnetization components
            TitleArray.Column{1} = 'Time (ms)';
            TitleArray.Column{2} = 'Mx/M0';
            TitleArray.Column{3} = 'My/M0';
            TitleArray.Column{4} = 'Mz/M0';
            TitleArray.Column{5} = 'Mxy/M0';
            
            ResultMatrix = [reshape(handles.Time,1,[]); reshape(handles.Mx,1,[]); ...
                reshape(handles.My,1,[]); reshape(handles.Mz,1,[]); ...
                reshape(sqrt((handles.Mx).*handles.Mx+(handles.My).*handles.My),1,[])];
        
end

fileID = fopen(handles.OutputFile,'w');

if (fileID < 0)
    errordlg('Invalid Output Filename','Error');
else
    fclose(fileID);
    if (exist('ResultMatrix','var') > 0)
        switch handles.OutputFileFormat
            case 'Excel'
                %******************************************************************
                % Save simulation results in Microsoft Excel format.
                %******************************************************************
                xlswrite(handles.OutputFile,TitleArray.Column(1),1,'A1');
                xlswrite(handles.OutputFile,TitleArray.Column(2),1,'B1');
                xlswrite(handles.OutputFile,TitleArray.Column(3),1,'C1');
                xlswrite(handles.OutputFile,TitleArray.Column(4),1,'D1');
                xlswrite(handles.OutputFile,TitleArray.Column(5),1,'E1');

                xlswrite(handles.OutputFile,ResultMatrix',1,'A3');

            case 'Text'
                %******************************************************************
                % Save simulation results in text format.
                %******************************************************************
                fileID = fopen(handles.OutputFile,'w');
                fprintf(fileID,'%8.4f     %8.6f		%8.6f		%8.6f		%8.6f\n',ResultMatrix);
                fclose(fileID);
        end;
    else
        errordlg('Perform a Simulation Before Attempting to Save Results','Error');
    end;
end;