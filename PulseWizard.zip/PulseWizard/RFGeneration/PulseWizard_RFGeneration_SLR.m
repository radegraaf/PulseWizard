function varargout = PulseWizard_RFGeneration_SLR(varargin)

% PULSEWIZARD_RFGENERATION_SLR MATLAB code for PulseWizard_RFGeneration_SLR.fig
%      PULSEWIZARD_RFGENERATION_SLR, by itself, creates a new PULSEWIZARD_RFGENERATION_SLR or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFGENERATION_SLR returns the handle to a new PULSEWIZARD_RFGENERATION_SLR or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFGENERATION_SLR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFGENERATION_SLR.M with the given input arguments.
%
%      PULSEWIZARD_RFGENERATION_SLR('Property','Value',...) creates a new PULSEWIZARD_RFGENERATION_SLR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFGeneration_SLR_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFGeneration_SLR_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFGeneration_SLR

% Last Modified by GUIDE v2.5 28-Mar-2017 11:51:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFGeneration_SLR_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFGeneration_SLR_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard_RFGeneration_SLR is made visible.
function PulseWizard_RFGeneration_SLR_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFGeneration_SLR (see VARARGIN)

% Choose default command line output for PulseWizard_RFGeneration_SLR
handles.output = hObject;

TransferredParameters = varargin{1};
NumericalParameters = TransferredParameters{1};
StringParameters = TransferredParameters{2};
InitializeParameters = TransferredParameters{3};

handles.NumberOfPoints = NumericalParameters(1);
handles.PulseLength = NumericalParameters(2);
handles.FrequencyOffset = NumericalParameters(3);
handles.InitialPhase = NumericalParameters(4);
handles.RFPulseFamilySelected = StringParameters;

handles.Initialize = InitializeParameters;

% Update handles structure
guidata(hObject, handles);

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .238*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .3712*ScreenWidth;
FigHeight = .225*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

if (strcmp(handles.Initialize,'Yes') > 0)
    % Initialize GUI values
    Initialize_GUI(hObject, handles);
end;


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFGeneration_SLR_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%**************************************************************************
% Code related to pulldown menu for SLR pulse type selection
%**************************************************************************
function SLRPulseType_Callback(hObject, eventdata, handles)
% Function executes when selecting a choice in the SLR pulse type pulldown menu

SLRPulseType = cellstr(get(hObject,'String'));
SLRPulseTypeSelected = SLRPulseType{get(hObject,'Value')};

% Save the new value
handles.SLRPulseType = SLRPulseTypeSelected;

guidata(hObject,handles)

% Update tooltip string
PBRipple_Edit_Callback(handles.PBRipple_Edit, eventdata, handles);
SBRipple_Edit_Callback(handles.SBRipple_Edit, eventdata, handles);

function SLRPulseType_CreateFcn(hObject, eventdata, handles)
% Create function for AFP modulation pulldown menu.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to pulldown menu for SLR pulse phase selection
%**************************************************************************
function SLRPulsePhase_Callback(hObject, eventdata, handles)
% Function executes when selecting a choice in the SLR pulse phase pulldown menu

SLRPulsePhase = cellstr(get(hObject,'String'));
SLRPulsePhaseSelected = SLRPulsePhase{get(hObject,'Value')};

% Save the new value
handles.SLRPulsePhase = SLRPulsePhaseSelected;

guidata(hObject,handles)

function SLRPulsePhase_CreateFcn(hObject, eventdata, handles)
% Create function for SLR pulse phase pulldown menu.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for Bandwidth
%**************************************************************************
function BandWidth_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for BandWidth
handles.BandWidth = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.BandWidth) > 0) || (isinf(handles.BandWidth) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for bandwidth.'];
    ErrorMessage2 = ['Error: Bandwidth set to valid default value (4.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.BandWidth = 4.0;
    set(hObject,'String',handles.BandWidth);
end;

% Only allow positive bandwidths
if (handles.BandWidth < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for bandwidth.'];
    ErrorMessage2 = ['Error: Bandwidth set to valid default value (' num2str(abs(handles.BandWidth)) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.BandWidth = abs(handles.BandWidth);
    set(hObject,'String',handles.BandWidth);
end;

% Updata GUI data structure
guidata(hObject,handles)

function BandWidth_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for bandwidth edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for passband ripple, PBRipple (%)
%**************************************************************************
function PBRipple_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for PBRipple
handles = guidata(hObject);
handles.PBRipple = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.PBRipple) > 0) || (isinf(handles.PBRipple) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for passband ripple.'];
    ErrorMessage2 = ['Error: Passband ripple set to valid default value (1.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.PBRipple = 1.0;
    set(hObject,'String',handles.PBRipple);
end;

% Only allow positive passband ripple
if ((handles.PBRipple <= 0) || (handles.PBRipple >100))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for passband ripple.'];
    ErrorMessage2 = ['Error: Passband ripple set to valid default value (1.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.PBRipple = 1.0;
    set(hObject,'String',handles.PBRipple);
end;

set(hObject,'TooltipString','Passband ripple [typical value = 1.0]');       

% Updata GUI data structure
guidata(hObject,handles)

function PBRipple_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for PBRipple edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for stopband ripple, SBRipple
%**************************************************************************
function SBRipple_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for SBRipple
handles = guidata(hObject);
handles.SBRipple = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.SBRipple) > 0) || (isinf(handles.SBRipple) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for stopband ripple.'];
    ErrorMessage2 = ['Error: Stopband ripple set to valid default value (1.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.SBRipple = 1.0;
    set(hObject,'String',handles.SBRipple);
end;

% Only allow positive stopband ripple
if ((handles.SBRipple <= 0) || (handles.SBRipple >100))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for stopband ripple.'];
    ErrorMessage2 = ['Error: Stopband ripple set to valid default value (1.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.SBRipple = 1.0;
    set(hObject,'String',handles.SBRipple);
end;

set(hObject,'TooltipString','Stopband ripple [typical value = 1.0]');

% Updata GUI data structure
guidata(hObject,handles)

function SBRipple_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for SBRipple edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to push button for start RF Pulse Generation
%**************************************************************************
function GenerateRFPulse_PushButton_Callback(hObject, eventdata, handles)
% Function executes when pushing the Generate RF Pulse button

switch handles.SLRPulseType
    case {'Small nutation','Excitation','Inversion','Refocusing','Saturation'}
        
        switch handles.SLRPulsePhase
            case {'Linear','Maximum','Minimum'}
                [time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateSLR(handles);
                PulseWizard_RFPulse(time,RF,freq,phs,grad);

                % Calculated RF pulse information must be transferred to main
                % RF generation window for saving purposes.
                % 1. Retrieve GUI data structure from main RF generation window
                hObject = findall(0,'Name','PulseWizard_RFGeneration');
                handles = guidata(hObject);

                % 2. Add RF pulse attributes to handles
                handles.time = time;
                handles.RF = RF;
                handles.freq = freq;
                handles.phs = phs;
                handles.grad = grad;

                % 3. Updata GUI data structure in main RF generation window
                guidata(hObject,handles)
            otherwise
                 errordlg('Select An SLR Pulse Phase Before Generating RF Pulse','Error');
        end;

    otherwise
        errordlg('Select An SLR Pulse Type Before Generating RF Pulse','Error');
end;

%**************************************************************************
% Code related to GUI/handles parameter initialization
%**************************************************************************
function Initialize_GUI(hObject, handles)

handles.SLRPulseType = 'SLR Pulse Type';
handles.SLRPulsePhase = 'SLR Pulse Phase';
handles.BandWidth = 4.0;
handles.PBRipple = 1.0;
handles.SBRipple = 1.0;

% Update GUI data structure
guidata(hObject, handles);
