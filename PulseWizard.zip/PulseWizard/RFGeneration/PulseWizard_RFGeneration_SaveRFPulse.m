function PulseWizard_RFGeneration_SaveRFPulse(handles)

%**************************************************************************
% Function for writing the generated RF pulse to file according
% to a specified MR vendor or PulseWizard format.
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************

fileID = fopen(handles.OutputFile,'w+');

if (fileID < 0)
    % Error dialog if the output file cannot be opened
    errordlg('Output file cannot be opened.','Error');
else
    switch handles.OutputFileFormat
        case 'PulseWizard'
            if (isfield(handles,'freq') < 1)
                handles.freq = 0.0*handles.phs;
            end;
            
            if (length(handles.RF) ~= length(handles.grad))
                handles.grad = 0.0*handles.RF + 1.0;
            end;
            
            % Save generated RF pulse in PulseWizard format
            OutPutMatrix = [reshape(handles.RF,1,[]); reshape(handles.freq,1,[]); reshape(handles.phs,1,[]); reshape(handles.grad,1,[])];
            fprintf(fileID,'%10.8f		%10.8f		%10.8f		%10.8f\n',OutPutMatrix);
            fclose(fileID);
            
        case 'Bruker'
            % Save generated RF pulse in Bruker format
            Bruker.Header{1} = '##TITLE= /xw2.6/exp/stan/nmr/lists/wave/Pulse.rfc\n';
            Bruker.Header{2} = '##JCAMP-DX= 5.00 Bruker JCAMP library\n';
            Bruker.Header{3} = '##DATA TYPE= Shape Data\n';
            Bruker.Header{4} = '##ORIGIN= Bruker Analytik GmbH\n';
            Bruker.Header{5} = '##OWNER= <nmrsu>\n';
            Bruker.Header{6} = '##DATE= 101/05/04\n';
            Bruker.Header{7} = '##TIME= 09:29:25\n';

            Bruker.Header{8} = ['##MINX= ' num2str(min(100*handles.RF)) '\n'];
            Bruker.Header{9} = ['##MAXX= ' num2str(max(100*handles.RF)) '\n'];
            Bruker.Header{10} = ['##MINY= ' num2str(min(handles.phs)) '\n'];
            Bruker.Header{11} = ['##MAXY= ' num2str(max(handles.phs)) '\n'];
            Bruker.Header{12} = '##$SHAPE_EXMODE= Refocussing\n';
            Bruker.Header{13} = '##$SHAPE_TOTROT= 180\n';
            Bruker.Header{14} = '##$SHAPE_BWFAC= 100\n';
            Bruker.Header{15} = ['##$SHAPE_INTEGFAC= ' num2str(sum(abs(handles.RF))/length(handles.RF)) '\n'];
            Bruker.Header{16} = '##$SHAPE_REPHFAC=50\n';
            Bruker.Header{17} = '##$SHAPE_TYPE=conventional\n';
            Bruker.Header{18} = '##$SHAPE_MODE= 0\n';
            Bruker.Header{19} = ['##NPOINTS= ' num2str(length(handles.RF)) '\n'];
            Bruker.Header{20} = '##XYPOINTS= (XY..XY)\n';
            Bruker.Header{21} = '##END=';

            % Write header to file
            %
            % Note that entries 12, 13, 14 and 16 should be 
            % modified to resemble the RF pulse characteristics.
            for HeaderCounter = 1:20;
                fprintf(fileID,char(Bruker.Header(HeaderCounter)),' ');
            end;
            
            % Write RF pulse to file
            RFmatrix = [100*handles.RF; handles.phs];

            fprintf(fileID,'%5.4f,  %8.4f\n',RFmatrix);

            fprintf(fileID,char(Bruker.Header(21)),' ');
            fclose(fileID);
        otherwise
            warndlg('This output file format is not yet implemented.','Warning');
            fclose(fileID);
    end;
end;