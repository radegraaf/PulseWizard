function varargout = PulseWizard_RFPulse(varargin)
% PULSEWIZARD_RFPULSE MATLAB code for PulseWizard_RFPulse.fig
%      PULSEWIZARD_RFPULSE, by itself, creates a new PULSEWIZARD_RFPULSE or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFPULSE returns the handle to a new PULSEWIZARD_RFPULSE or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFPULSE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFPULSE.M with the given input arguments.
%
%      PULSEWIZARD_RFPULSE('Property','Value',...) creates a new PULSEWIZARD_RFPULSE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFPulse_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFPulse_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFPulse

% Last Modified by GUIDE v2.5 23-Sep-2016 16:05:24

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFPulse_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFPulse_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard_RFPulse is made visible.
function PulseWizard_RFPulse_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFPulse (see VARARGIN)

% Choose default command line output for PulseWizard_RFPulse
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .613*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .362*ScreenWidth;
FigHeight = .64235*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

time = varargin{1};
RF = varargin{2};
ErrorRF = sum(isnan(RF)) + sum(isinf(RF)) + sum(isempty(RF));
freq = varargin{3};
ErrorFreq = sum(isnan(freq)) + sum(isinf(freq)) + sum(isempty(freq));
phs = varargin{4};
ErrorPhs = sum(isnan(phs)) + sum(isinf(phs)) + sum(isempty(phs));
grad = varargin{5};
ErrorGrad = sum(isnan(grad)) + sum(isinf(grad)) + sum(isempty(grad));
ErrorTotal = ErrorRF + ErrorFreq + ErrorPhs + ErrorGrad;

if (ErrorTotal == 0)
    axes(handles.axes1);
    plot(time,RF)
    if (min(RF) == max(RF))
        axis([0 max(time) min(RF)-1 max(RF)+1]);
    else
        axis([0 max(time) min(RF) max(RF)]);
    end;
    xlabel('Time (ms)');
    ylabel('RF amplitude');
    grid on;

    axes(handles.axes2);
    plot(time,phs)
    if (min(phs) == max(phs))
        axis([0 max(time) min(phs)-1 max(phs)+1]);
    else
        axis([0 max(time) min(phs) max(phs)]);
    end;
    xlabel('Time (ms)');
    ylabel('Phase (deg)');
    grid on;

    axes(handles.axes3);
    plot(time,freq)
    if (min(freq) == max(freq))
        axis([0 max(time) min(freq)-1 max(freq)+1]);
    else
        axis([0 max(time) min(freq) max(freq)]);
    end;
    xlabel('Time (ms)');
    ylabel('Frequency (kHz)');
    grid on;

    if (min(grad) == max(grad))
        % No gradient modulation
        % Show real/imaginary RF modulation
        axes(handles.axes4);
        plot(time,RF.*cosd(phs),'b',time,RF.*sind(phs),'r')
        if (min(RF) == max(RF))
            axis([0 max(time) min(RF)-1 max(RF)+1]);
        else
            axis([0 max(time) -1.0*max(RF) max(RF)]);
        end;
        xlabel('Time (ms)');
        ylabel('RF (real/imaginary)');
    else
        % Gradient-modulated RF pulse
        axes(handles.axes4);
        plot(time,grad,'b')
        axis([0 max(time) min(grad) max(grad)]);
        xlabel('Time (ms)');
        ylabel('Gradient');    
    end;
    grid on;
else
    errordlg('RF pulse waveform contains invalid values.','Error');
    
    ErrorMessage1 = ['Error: RF pulse waveform contains invalid values.'];
    ErrorMessage2 = ['Error: Check input RF pulse or RF pulse calculation.'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
end;


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFPulse_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
