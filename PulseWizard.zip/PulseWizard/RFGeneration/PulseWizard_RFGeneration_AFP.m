function varargout = PulseWizard_RFGeneration_AFP(varargin)

% PULSEWIZARD_RFGENERATION_AFP MATLAB code for PulseWizard_RFGeneration_AFP.fig
%      PULSEWIZARD_RFGENERATION_AFP, by itself, creates a new PULSEWIZARD_RFGENERATION_AFP or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFGENERATION_AFP returns the handle to a new PULSEWIZARD_RFGENERATION_AFP or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFGENERATION_AFP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFGENERATION_AFP.M with the given input arguments.
%
%      PULSEWIZARD_RFGENERATION_AFP('Property','Value',...) creates a new PULSEWIZARD_RFGENERATION_AFP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFGeneration_AFP_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFGeneration_AFP_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFGeneration_AFP

% Last Modified by GUIDE v2.5 18-Jul-2018 15:55:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFGeneration_AFP_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFGeneration_AFP_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard_RFGeneration_AFP is made visible.
function PulseWizard_RFGeneration_AFP_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFGeneration_AFP (see VARARGIN)

% Choose default command line output for PulseWizard_RFGeneration_AFP
handles.output = hObject;

TransferredParameters = varargin{1};
NumericalParameters = TransferredParameters{1};
StringParameters = TransferredParameters{2};
InitializeParameters = TransferredParameters{3};

handles.NumberOfPoints = NumericalParameters(1);
handles.PulseLength = NumericalParameters(2);
handles.FrequencyOffset = NumericalParameters(3);
handles.InitialPhase = NumericalParameters(4);
handles.RFPulseFamilySelected = StringParameters;

handles.Initialize = InitializeParameters;

% Update handles structure
guidata(hObject, handles);

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .238*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .3712*ScreenWidth;
FigHeight = .225*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

if (strcmp(handles.Initialize,'Yes') > 0)
    % Initialize GUI values
    Initialize_GUI(hObject, handles);
end;


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFGeneration_AFP_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%**************************************************************************
% Code related to pulldown menu for AFP modulations
%**************************************************************************
function AFPModulations_Callback(hObject, eventdata, handles)
% Function executes when selecting a choice in the AFP modulation pulldown menu

AFPModulation = cellstr(get(hObject,'String'));
AFPModulationSelected = AFPModulation{get(hObject,'Value')};

% Save the new density value
handles.AFPModulation = AFPModulationSelected;

guidata(hObject,handles)

% Update tooltip string
switch handles.AFPModulation
    case {'HSn', 'tanh/tan'}
        RFConstant1_Edit_Callback(handles.RFConstant1_Edit, eventdata, handles);
        RFConstant2_Edit_Callback(handles.RFConstant2_Edit, eventdata, handles);
        RFConstant3_Edit_Callback(handles.RFConstant3_Edit, eventdata, handles);
end;

function AFPModulations_CreateFcn(hObject, eventdata, handles)
% Create function for AFP modulation pulldown menu.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for Bandwidth
%**************************************************************************
function BandWidth_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for BandWidth
handles.BandWidth = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.BandWidth) > 0) || (isinf(handles.BandWidth) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for bandwidth.'];
    ErrorMessage2 = ['Error: Bandwidth set to valid default value (4.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.BandWidth = 4.0;
    set(hObject,'String',handles.BandWidth);
end;

% Only allow positive bandwidths
if (handles.BandWidth < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for bandwidth.'];
    ErrorMessage2 = ['Error: Bandwidth set to valid default value (' num2str(abs(handles.BandWidth)) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.BandWidth = abs(handles.BandWidth);
    set(hObject,'String',handles.BandWidth);
end;

% Updata GUI data structure
guidata(hObject,handles)

function BandWidth_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for bandwidth edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for RFConstant1
%**************************************************************************
function RFConstant1_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for RFConstant1
handles = guidata(hObject);
handles.RFConstant1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.RFConstant1) > 0) || (isinf(handles.RFConstant1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for RF constant 1.'];
    switch handles.AFPModulation
        case 'HSn'
            ErrorMessage2 = ['Error: RF constant 1 set to valid default value (5.3).'];
            handles.RFConstant1 = 5.3;
        case 'tanh/tan'
            ErrorMessage2 = ['Error: RF constant 1 set to valid default value (10).'];
            handles.RFConstant1 = 10;
        otherwise
            ErrorMessage2 = ['Error: RF constant 1 set to valid default value (5.3).'];
            handles.RFConstant1 = 5.3;
    end;     
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    set(hObject,'String',handles.RFConstant1);
end;

switch handles.AFPModulation
    case 'HSn'
        set(hObject,'TooltipString','RF modulation truncation factor [typical value = 5.3]');       
    case 'tanh/tan'
        set(hObject,'TooltipString','RF modulation truncation factor [typical value = 10]');
end;

% Updata GUI data structure
guidata(hObject,handles)

function RFConstant1_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for RFConstant1 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for RFConstant2
%**************************************************************************
function RFConstant2_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for RFConstant2
handles = guidata(hObject);
handles.RFConstant2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.RFConstant2) > 0) || (isinf(handles.RFConstant2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for RF constant 2.'];
    switch handles.AFPModulation
        case 'HSn'
            ErrorMessage2 = ' ';
        case 'tanh/tan'
            ErrorMessage2 = ['Error: RF constant 2 set to valid default value (1.52).'];
            handles.RFConstant2 = 1.52;
        otherwise
            ErrorMessage2 = ['Error: RF constant 2 set to valid default value (1.0).'];
            handles.RFConstant2 = 1.00;
    end;     
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    set(hObject,'String',handles.RFConstant2);
end;

switch handles.AFPModulation
    case 'HSn'
        set(handles.RFConstant2_Text,'Visible','Off');
        set(hObject,'Visible','Off');
    case 'tanh/tan'
        set(hObject,'TooltipString','Frequency modulation truncation factor [typical value = 1.52]');
        set(handles.RFConstant2_Text,'Visible','On');
        set(hObject,'Visible','On');
        
        % Only allow values > 0 and < pi/2
        if (handles.RFConstant2 < 1e-3)
            ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for RF constant 2.'];
            ErrorMessage2 = ['Error: RF constant 2 set to valid default value (0.001).'];    
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
            handles.RFConstant2 = 1e-3;
            set(hObject,'String',handles.RFConstant2);
        end;
        
        if (handles.RFConstant2 > 1.57)
            ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for RF constant 2.'];
            ErrorMessage2 = ['Error: RF constant 2 set to valid default value (1.52).'];    
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
            
            handles.RFConstant2 = 1.52;
            set(hObject,'String',handles.RFConstant2);
        end;
end;

% Updata GUI data structure
guidata(hObject,handles)

function RFConstant2_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for RFConstant2 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for RFConstant3
%**************************************************************************
function RFConstant3_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for RFConstant3
handles = guidata(hObject);
handles.RFConstant3 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.RFConstant3) > 0) || (isinf(handles.RFConstant3) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for RF constant 3.'];
    switch handles.AFPModulation
        case 'HSn'
            ErrorMessage2 = ['Error: RF constant 3 set to valid default value (1.0).'];
            handles.RFConstant3 = 1.00;
        case 'tanh/tan'
            ErrorMessage2 = ' ';
        otherwise
            ErrorMessage2 = ['Error: RF constant 3 set to valid default value (1.0).'];
            handles.RFConstant3 = 1.00;
    end;     
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    set(hObject,'String',handles.RFConstant3);
end;

switch handles.AFPModulation
    case 'HSn'
        set(hObject,'TooltipString','Power n in RF modulation [typical value = 1]');
        set(handles.RFConstant3_Text,'Visible','On');
        set(hObject,'Visible','On');
        
        % Only allow values >= 0
        if (handles.RFConstant3 < 0)
            ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for RF constant 3.'];
            ErrorMessage2 = ['Error: RF constant 3 set to valid default value (1.0).'];    
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
            
            handles.RFConstant3 = 1.0;
            set(hObject,'String',handles.RFConstant3);
        end;
        
    case 'tanh/tan'
        set(handles.RFConstant3_Text,'Visible','Off');
        set(hObject,'Visible','Off');
end;

% Updata GUI data structure
guidata(hObject,handles)

function RFConstant3_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for RFConstant3 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to push button for start RF Pulse Generation
%**************************************************************************
function GenerateRFPulse_PushButton_Callback(hObject, eventdata, handles)
% Function executes when pushing the Generate RF Pulse button

switch handles.AFPModulation
    case {'HSn','tanh/tan'}
        [time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateAFP(handles);
        PulseWizard_RFPulse(time,RF,freq,phs,grad);
        
        % Calculated RF pulse information must be transferred to main
        % RF generation window for saving purposes.
        % 1. Retrieve GUI data structure from main RF generation window
        hObject = findall(0,'Name','PulseWizard_RFGeneration');
        handles = guidata(hObject);

        % 2. Add RF pulse attributes to handles
        handles.time = time;
        handles.RF = RF;
        handles.freq = freq;
        handles.phs = phs;
        
        % 3. Updata GUI data structure in main RF generation window
        guidata(hObject,handles)

    otherwise
        errordlg('Select An AHP/AFP Modulation Function Before Generating RF Pulse','Error');
end;

%**************************************************************************
% Code related to GUI/handles parameter initialization
%**************************************************************************
function Initialize_GUI(hObject, handles)

handles.AFPModulation = 'AFP/AHP Modulations';
handles.BandWidth = 4.0;
handles.RFConstant1 = 5.3;
handles.RFConstant2 = 5.3;
handles.RFConstant3 = 1.0;

% Update GUI data structure
guidata(hObject, handles);
