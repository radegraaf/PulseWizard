function [Time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateAM(handles)

%**************************************************************************
% Function for the calculation of amplitude-modulated (AM) RF pulses.
%
% Notes:
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************
TimeResolution = handles.PulseLength/(handles.NumberOfPoints-1);
Time = 0:TimeResolution:handles.PulseLength;

switch handles.AMModulation
    case 'Fermi'
        %******************************************************************
        % Fermi RF pulse.
        %******************************************************************

        % Define apparent time, running from -1 to +1
        TimeApp = -1:2/(handles.NumberOfPoints-1):1;
             
        % RF modulation      
        RF(1:handles.NumberOfPoints) = 1.0./(1.0 + exp((abs(TimeApp) - handles.RFConstant1)/handles.RFConstant2));
        
        % Normalize RF to [0 .. 1]
        RF = RF./max(RF);
        
        % Frequency modulation
        freq(1:handles.NumberOfPoints) = handles.FrequencyOffset; 
        
        % Calculate phase modulation from frequency modulation
        phs = 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
        
    case 'Gaussian'
        %******************************************************************
        % Gaussian RF pulse. 
        %
        % Original/relevant publications:
        % C. Bauer, R. Freeman, T. Frenkiel, J. Keeler, A. J. Shaka
        % J. Magn. Reson. 58, 442-457 (1984)
        %
        % See also Chapter 5 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from -1 to +1
        TimeApp = -1:2/(handles.NumberOfPoints-1):1;
        
        % Convert truncation level (%) to exponential scaling
        GaussianScale = 1.0*log(handles.RFConstant1/100.0);
        
        % RF modulation (first segment)       
        RF(1:handles.NumberOfPoints) = exp(GaussianScale*TimeApp.*TimeApp);
        
        % Frequency modulation
        freq(1:handles.NumberOfPoints) = handles.FrequencyOffset; 
        
        % Calculate phase modulation from frequency modulation
        phs = 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
        
     case 'Hermitian'
        %******************************************************************
        % Hermitian RF pulse. 
        %
        % Original/relevant publications:
        % W. S. Warren
        % J. Chem. Phys. 81, 5437-5448 (1984)
        %
        % See also Chapter 5 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from -1 to +1
        TimeApp = -1:2/(handles.NumberOfPoints-1):1;
        
        switch handles.RFConstant1
            case 90
                % RF modulation    
                RF(1:handles.NumberOfPoints) = (1.0 - 6.003*TimeApp.^2).*exp(-9.0*TimeApp.^2);
            case 180
                % RF modulation    
                RF(1:handles.NumberOfPoints) = (1.0 - 8.604*TimeApp.^2).*exp(-9.0*TimeApp.^2);
        end;
        
        % Frequency modulation
        freq(1:handles.NumberOfPoints) = handles.FrequencyOffset; 
        
        % Calculate phase modulation from frequency modulation
        phs = 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;

     case 'Sinc'
        %******************************************************************
        % Sinc RF pulse. 
        %
        % See also Chapter 5 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from -1 to +1
        TimeApp = -1:2/(handles.NumberOfPoints-1):1;
        
        % RF modulation    
        RF(1:handles.NumberOfPoints) = sin(pi*handles.RFConstant1*TimeApp)./TimeApp;
        
        % Normalize RF to [0 .. 1] and remove potential 
        % 'divide by zero' points
        RF = RF./max(RF);
        coor = find(isnan(RF) > 0);
        RF(coor) = 1.0;
       
        % Frequency modulation
        freq(1:handles.NumberOfPoints) = handles.FrequencyOffset; 
        
        % Calculate phase modulation from frequency modulation
        phs = 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
end;

 % Constant gradient modulation
 grad = 0.0*phs + 1.0;