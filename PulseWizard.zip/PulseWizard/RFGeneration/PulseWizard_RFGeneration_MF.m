function varargout = PulseWizard_RFGeneration_MF(varargin)

% PULSEWIZARD_RFGENERATION_MF MATLAB code for PulseWizard_RFGeneration_MF.fig
%      PULSEWIZARD_RFGENERATION_MF, by itself, creates a new PULSEWIZARD_RFGENERATION_MF or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFGENERATION_MF returns the handle to a new PULSEWIZARD_RFGENERATION_MF or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFGENERATION_MF('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFGENERATION_MF.M with the given input arguments.
%
%      PULSEWIZARD_RFGENERATION_MF('Property','Value',...) creates a new PULSEWIZARD_RFGENERATION_MF or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFGeneration_MF_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFGeneration_MF_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFGeneration_MF

% Last Modified by GUIDE v2.5 18-Jul-2018 16:37:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFGeneration_MF_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFGeneration_MF_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard_RFGeneration_MF is made visible.
function PulseWizard_RFGeneration_MF_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFGeneration_MF (see VARARGIN)

% Choose default command line output for PulseWizard_RFGeneration_MF
handles.output = hObject;

TransferredParameters = varargin{1};
NumericalParameters = TransferredParameters{1};
StringParameters = TransferredParameters{2};
ArrayParameters1 = TransferredParameters{3};
ArrayParameters2 = TransferredParameters{4};
ArrayParameters3 = TransferredParameters{5};
InitializeParameters = TransferredParameters{6};

handles.NumberOfPoints = NumericalParameters(1);
handles.PulseLength = NumericalParameters(2);
handles.FrequencyOffset = NumericalParameters(3);
handles.InitialPhase = NumericalParameters(4);
handles.RFPulseFamilySelected = StringParameters;

handles.RF = ArrayParameters1;
handles.phs = ArrayParameters2;
handles.grad = ArrayParameters3;

handles.Initialize = InitializeParameters;

% Update handles structure
guidata(hObject, handles);

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .238*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .3712*ScreenWidth;
FigHeight = .225*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

if (strcmp(handles.Initialize,'Yes') > 0)
    % Initialize GUI values
    Initialize_GUI(hObject, handles);
end;


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFGeneration_MF_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%**************************************************************************
% Code related to pulldown menu for time reversal of pulse 2
%**************************************************************************
function TimeReversalPulse2Type_Callback(hObject, eventdata, handles)
% Function executes when selecting the time-orientation of pulse 2

TimeReversalStrings = cellstr(get(hObject,'String'));
TimeReversalSelected = TimeReversalStrings{get(hObject,'Value')};

% Save the new value
handles.TimeReversalPulse2Type = TimeReversalSelected;

guidata(hObject,handles)

function TimeReversalPulse2Type_CreateFcn(hObject, eventdata, handles)
% Create function for AFP modulation pulldown menu.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to pulldown menu for SLR pulse phase selection
%**************************************************************************
function BSCompensation_Callback(hObject, eventdata, handles)
% Function executes when selecting Bloch-Siegert compensation

BCCompensationStrings = cellstr(get(hObject,'String'));
BCCompensationSelected = BCCompensationStrings{get(hObject,'Value')};

% Save the new value
handles.BSCompensation = BCCompensationSelected;

% Updata GUI data structure
guidata(hObject,handles)

function BSCompensation_CreateFcn(hObject, eventdata, handles)
% Create function for SLR pulse phase pulldown menu.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for the frequency of band 1
%**************************************************************************
function Frequency1_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for Frequency1
handles.Frequency1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.Frequency1) > 0) || (isinf(handles.Frequency1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for frequency 1.'];
    ErrorMessage2 = ['Error: Frequency 1 set to valid default value (4.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.Frequency1 = 4.0;
    set(hObject,'String',handles.Frequency1);
end;

% Updata GUI data structure
guidata(hObject,handles)

function Frequency1_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for Frequency1 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for the frequency of band 2
%**************************************************************************
function Frequency2_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for Frequency2
handles.Frequency2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.Frequency2) > 0) || (isinf(handles.Frequency2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for frequency 2.'];
    ErrorMessage2 = ['Error: Frequency 2 set to valid default value (-4.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.Frequency2 = -4.0;
    set(hObject,'String',handles.Frequency2);
end;

% Updata GUI data structure
guidata(hObject,handles)

function Frequency2_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for Frequency2 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for the phase of frequency band 1; phase1
%**************************************************************************
function Phase1_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for phase1
handles = guidata(hObject);
handles.Phase1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.Phase1) > 0) || (isinf(handles.Phase1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for phase 1.'];
    ErrorMessage2 = ['Error: Phase 1 set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.Phase1 = 0.0;
    set(hObject,'String',handles.Phase1);
end;

set(hObject,'TooltipString','Phase for frequency band 1');       

% Updata GUI data structure
guidata(hObject,handles)

function Phase1_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for Phase1 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for the phase of frequency band 2; phase2
%**************************************************************************
function Phase2_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for phase1
handles = guidata(hObject);
handles.Phase2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.Phase2) > 0) || (isinf(handles.Phase2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for phase 2.'];
    ErrorMessage2 = ['Error: Phase 2 set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.Phase2 = 0.0;
    set(hObject,'String',handles.Phase2);
end;

set(hObject,'TooltipString','Phase for frequency band 2');       

% Updata GUI data structure
guidata(hObject,handles)

function Phase2_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for Phase2 edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%**************************************************************************
% Code related to edit box for Bloch-Siegert Compensation RF amplitude
%**************************************************************************
function RFAmplitudeBSC_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for RFAmplitudeBSC
handles = guidata(hObject);
handles.RFAmplitudeBSC = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.RFAmplitudeBSC) > 0) || (isinf(handles.RFAmplitudeBSC) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for Bloch-Siegert RF amplitude.'];
    ErrorMessage2 = ['Error: Bloch-Siegert RF amplitude set to valid default value (2.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.RFAmplitudeBSC = 2.0;
    set(hObject,'String',handles.RFAmplitudeBSC);
end;

set(hObject,'TooltipString','RF amplitude for a single-frequency RF pulse');

% Updata GUI data structure
guidata(hObject,handles)

function RFAmplitudeBSC_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for RFAmplitudeBSC edit box.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to push button for start RF Pulse Generation
%**************************************************************************
function GenerateRFPulse_PushButton_Callback(hObject, eventdata, handles)
% Function executes when pushing the Generate RF Pulse button
  
[time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateMF(handles);
PulseWizard_RFPulse(time,RF,freq,phs,grad);

% Calculated RF pulse information must be transferred to main
% RF generation window for saving purposes.
% 1. Retrieve GUI data structure from main RF generation window
hObject = findall(0,'Name','PulseWizard_RFGeneration');
handles = guidata(hObject);

% 2. Add RF pulse attributes to handles
handles.time = time;
handles.RF = RF;
handles.freq = freq;
handles.phs = phs;
handles.grad = grad;

% 3. Updata GUI data structure in main RF generation window
guidata(hObject,handles)


%**************************************************************************
% Code related to GUI/handles parameter initialization
%**************************************************************************
function Initialize_GUI(hObject, handles)

handles.TimeReversalPulse2Type = 'Time Reversal Pulse 2';
handles.BSCompensation = 'SLR Pulse Phase';
handles.Frequency1 = 5.0;
handles.Frequency2 = -5.0;
handles.Phase1 = 0.0;
handles.Phase2 = 0.0;
handles.RFAmplitudeBSC = 1.0;

% Update GUI data structure
guidata(hObject, handles);
