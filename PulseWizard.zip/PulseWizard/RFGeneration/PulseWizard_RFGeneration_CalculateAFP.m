function [Time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateAFP(handles)

%**************************************************************************
% Function for the calculation of adiabatic full passage (AFP)
% RF pulses based on a range of RF and frequency/phase
% modulation functions.
%
% Notes:
% 1. Number of points for AFP pulses refers to points per AHP segment.
% 2. RF and phase modulations are forced to be time-symmetric.
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************
TimeResolution = handles.PulseLength/(2*handles.NumberOfPoints-1);
Time = 0:TimeResolution:handles.PulseLength;

switch handles.AFPModulation
    case 'HSn'
        %******************************************************************
        % Offset-independent adiabaticity (OIA) pulses based on
        % hyperbolic secant functions raised to a power n.
        % n = 1 leads to the original hyperbolic secant RF pulses.
        %
        % Original/relevant publications:
        % 1. M. S. Silver, R. I. Joseph, D. I. Hoult, 
        %    J. Magn. Reson. 59, 347-351 (1984)
        % 2. A. Tannus, M. Garwood,
        %    J. Magn. Reson. 120A, 133-137 (1996)
        %
        % See also Chapter 5 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from 0 to +1
        TimeApp = 0:1/(handles.NumberOfPoints-1):1;
        
        % RF modulation (first segment)
        RF(1:handles.NumberOfPoints) = sech(handles.RFConstant1*(1.0 - TimeApp).^handles.RFConstant3);
        % Normalize RF modulation to 0 to +1 range
        RF = RF/max(RF);
        
        % Frequency modulation
        freq = cumsum(RF.*RF);
        % Normalize frequency modulation to 0 to +1 range
        freq = 1.0 - (freq/max(freq));
        % Scale frequency modulation to full BandWidth
        freq = (handles.BandWidth/2.0)*freq;
        
        % Phase modulation = time integral of frequency
        phs = 360*cumsum(freq*TimeResolution);
        % Force first point in phase modulation to zero
        phs = phs - phs(1);
        
        % Calculate second half of pulse based on symmetry
        RF(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = RF(handles.NumberOfPoints:-1:1);
        freq(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = -1.0*freq(handles.NumberOfPoints:-1:1);
        phs(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = phs(handles.NumberOfPoints:-1:1);
        
        % Add frequency offset to frequency modulation
        freq = freq + handles.FrequencyOffset;
        
        % Add frequency offset as a phase ramp to phase modulation
        phs = phs + 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
        
    case 'tanh/tan'
        %******************************************************************
        % Adiabatic full passage pulses based on tanh/tan modulation that
        % closely reflect numerically optimized modulation (NOM) functions.
        %
        % Original/relevant publications:
        % 1. M. Garwood, Y. Ke,
        %    J. Magn. Reson. 94, 511-525 (1991)
        % 2. K. Ugurbil, M. Garwood, A. Rath,
        %    J. Magn. Reson. 80, 448-469 (1988)
        %
        % See also Chapter 5 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from 0 to +1
        TimeApp = 0:1/(handles.NumberOfPoints-1):1;
        
        % RF modulation (first segment)       
        RF(1:handles.NumberOfPoints) = tanh(handles.RFConstant1*TimeApp);
        
        % Frequency modulation (first segment)
        freq(1:handles.NumberOfPoints) = tan(handles.RFConstant2*(1.0 - TimeApp));
        
        % Normalize frequency modulation to 0 to +1 range
        freq = freq/max(freq);
        % Scale frequency modulation to full BandWidth
        freq = (handles.BandWidth/2.0)*freq;
        
        % Phase modulation = time integral of frequency
        phs = 360*cumsum(freq*TimeResolution);
        % Force first point in phase modulation to zero
        phs = phs - phs(1);      
        
        % Calculate second half of pulse based on symmetry
        RF(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = RF(handles.NumberOfPoints:-1:1);
        freq(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = -1.0*freq(handles.NumberOfPoints:-1:1);
        phs(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = phs(handles.NumberOfPoints:-1:1);        
        
        % Add frequency offset to frequency modulation
        freq = freq + handles.FrequencyOffset;
        
        % Add frequency offset as a phase ramp to phase modulation
        phs = phs + 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
 end;

 switch handles.RFPulseFamilySelected
     case 'AFP'
         % Return the entire calculated RF pulse
     case 'AHP'
         % Return first half of calculated AFP RF pulse
         RF = RF(1:handles.NumberOfPoints);
         freq = freq(1:handles.NumberOfPoints);
         phs = phs(1:handles.NumberOfPoints);
         
         TimeResolution = handles.PulseLength/(handles.NumberOfPoints-1);
         Time = 0:TimeResolution:handles.PulseLength;
      case 'RAHP'
         % Return second half of calculated AFP RF pulse
         RF = RF(handles.NumberOfPoints+1:2*handles.NumberOfPoints);
         freq = freq(handles.NumberOfPoints+1:2*handles.NumberOfPoints);
         phs = phs(handles.NumberOfPoints+1:2*handles.NumberOfPoints);
         
         TimeResolution = handles.PulseLength/(handles.NumberOfPoints-1);
         Time = 0:TimeResolution:handles.PulseLength;
 end;
 
 % Constant gradient modulation
 grad = 0.0*phs + 1.0;