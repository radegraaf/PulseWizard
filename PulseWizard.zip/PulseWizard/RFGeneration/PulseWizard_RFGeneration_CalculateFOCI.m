function [Time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateFOCI(handles)

%**************************************************************************
% Function for the calculation of FOCI pulses based on 
% adiabatic full passage (AFP) RF pulses.
%
% Notes:
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************
TimeResolution = handles.PulseLength/(handles.NumberOfPoints-1);
Time = 0:TimeResolution:handles.PulseLength;

switch handles.FOCIModulation
    case 'sech/tanh'
        %******************************************************************
        % FOCI based on HS modulation
        %
        % Original/relevant publications:
        % 1. Ordidge RJ, Wylezinska M, Hugg JW, Butterworth E, Franconi F,
        %    Magn. Reson. Med. 36, 562-566 (1996)
        % 2. Payne GS, Leach MO,
        %    Magn. Reson. Med. 37, 828-833 (1997)
        %
        % See also Chapter 6 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from -1 to +1
        TimeApp = -1:2/(handles.NumberOfPoints-1):1;
        
        % 1. Calculate standard sech/tanh pulse
        % RF modulation
        RF = sech(handles.RFConstant1*TimeApp);
        
        % Frequency modulation
        freq = -1.0*tanh(handles.RFConstant2*TimeApp);
        
        % Scale frequency modulation to full BandWidth
        freq = (handles.BandWidth/2.0)*freq;
        
        % 2. Convert sech/tanh pulse to a FOCI pulse
        coor = find(RF >= (1.0/handles.RFConstant3));

        % Gradient modulation
        grad = handles.RFConstant3*ones(1,handles.NumberOfPoints);
        grad(coor) = cosh(5.3*TimeApp(coor));

        % Calculate new RF and frequency modulations
        RF = RF.*grad;
        freq = freq.*grad;
        
        % Phase modulation = time integral of frequency
        phs = 360*cumsum(freq*TimeResolution);
        % Force first point in phase modulation to zero
        phs = phs - phs(1);
        
        % Add frequency offset to frequency modulation
        freq = freq + handles.FrequencyOffset;
        
        % Add frequency offset as a phase ramp to phase modulation
        phs = phs + 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
end;