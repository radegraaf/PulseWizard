function [Time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateSLR(handles)

%**************************************************************************
% Function for the calculation of RF pulses optimized with
% the Shinnar-Le Roux algorithm.
%
% Notes:
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************

% Prepare pulse parameters
PBRipple = handles.PBRipple/100; 	   % Passband (PB) ripple (% -> fraction) 
SBRipple = handles.SBRipple/100;       % Stopband (SB) ripple (% -> fraction)

% Convert the desired ripple levels into effective ripples
% needed in the filter design.
% See Table I in Pauly et al, IEEE TMI 10, 53-65 (1991)
switch handles.SLRPulseType
    case 'Small nutation'
        % Small nutation pulse
        FBnomialScalingFactor = 1;
    case 'Excitation'
        % Excitation
        PBRipple = sqrt(PBRipple/2);      
        SBRipple = SBRipple/sqrt(2);
        FBnomialScalingFactor = sqrt(1/2);
    case 'Inversion'
        % Inversion
        PBRipple = PBRipple/8;      
        SBRipple = sqrt(SBRipple/2);
        FBnomialScalingFactor = 1;
    case 'Refocusing'
        % Refocusing
        PBRipple = PBRipple/4;      
        SBRipple = sqrt(SBRipple);
        FBnomialScalingFactor = 1;
    case 'Saturation'
        % Saturation
        PBRipple = PBRipple/2;      
        SBRipple = sqrt(SBRipple);
        FBnomialScalingFactor = sqrt(1/2);       
end;

% Calculate transition band         
% See Eq. [21] in Pauly et al, IEEE TMI 10, 53-65 (1991) 
switch handles.SLRPulsePhase
    case 'Linear'
        % Linear phase pulse
        L1 = log10(PBRipple); L2 = log10(SBRipple);
        a1 = 5.309e-3; a2 = 7.114e-2; a3 = -4.761e-1;
        a4 = -2.66e-3; a5 = -5.941e-1; a6 = -4.278e-1;

        D = (a1*L1^2 + a2*L1 + a3)*L2 + (a4*L1^2 + a5*L1 + a6);
        
    case {'Maximum','Minimum'}
        % Minimum/maximum phase pulse
        L1 = log10(2*PBRipple); L2 = log10(SBRipple*SBRipple/2);
        a1 = 5.309e-3; a2 = 7.114e-2; a3 = -4.761e-1;
        a4 = -2.66e-3; a5 = -5.941e-1; a6 = -4.278e-1;

        D = 0.5*((a1*L1^2 + a2*L1 + a3)*L2 + (a4*L1^2 + a5*L1 + a6));
end;

% Calculate RF pulse parameters
R = handles.BandWidth*handles.PulseLength;
FractionalTransitionWidth = (D/R);
TransitionWidth = handles.BandWidth*FractionalTransitionWidth;

% Frequency point for PassBand
Fpb = 2*(handles.PulseLength/handles.NumberOfPoints)*(handles.BandWidth/2 - TransitionWidth/2);  
% Frequency point for StopBand
Fsb = 2*(handles.PulseLength/handles.NumberOfPoints)*(handles.BandWidth/2 + TransitionWidth/2);

FrequencyBandBoundaries = [0, Fpb, Fsb, 1];
FrequencyBandAmplitude = [1, 1, 0, 0];

% Calculate B polynomial (expressed in h)
switch handles.SLRPulsePhase
    case 'Linear'
        % Linear phase pulse
        FrequencyBandWeight1 = 1; 
        FrequencyBandWeight2 = PBRipple/SBRipple;
        FrequencyBandWeight = [FrequencyBandWeight1, FrequencyBandWeight2];
        
        % Calculate B polynomial with Parks-McClennan FIR algorithm
        B = firpm(handles.NumberOfPoints-1,FrequencyBandBoundaries,FrequencyBandAmplitude,FrequencyBandWeight);
        B = B*FBnomialScalingFactor;
        
        FIRnp =  4096;
        [h, ~] = freqz(B,1,FIRnp,'whole');  % Frequency response h to filter B calculated over FIRnp points                                   % Absolute value of h = absolute value
                                            % of pulse frequency profile. Only variable remaining is the phase,
                                            % which is expressed through the A polynomial.

    case {'Maximum','Minimum'}
        % Minimum/maximum phase pulse
        % Take a linear phase filter and convert it to a maximum phase
        % filter using Fourier and Hilbert transformations.

        FrequencyBandWeight1 = 1; 
        FrequencyBandWeight2 = 2*PBRipple/(SBRipple*SBRipple/2);
        FrequencyBandWeight = [FrequencyBandWeight1, FrequencyBandWeight2];

        % Calculate B polynomial with Parks-McClennan FIR algorithm
        B = firpm(2*handles.NumberOfPoints-2,FrequencyBandBoundaries,FrequencyBandAmplitude,FrequencyBandWeight);

        npB = length(B);                    % Length of B polynomial
        npzf = 32*2^ceil(log2(npB));        % Length of zerofilled B polynomial
        
        % Zerofill symmetrically around B
        Bzf = [zeros(1,ceil((npzf-npB)/2)) B zeros(1,floor((npzf-npB)/2))];
        Bfft = fftshift(fft(fftshift(Bzf)));
        % Force all values > 0 for log function 2 lines later
        Bfft = Bfft - min(real(Bfft)) + eps;
        
        % Code to calculate A from B via Hilbert transform
        % The matlab function 'Hilbert' can do this in one shot.

        y3 = sqrt(abs(Bfft)).*exp(-1i*imag(hilbert(log(sqrt(abs(Bfft))),length(Bfft))));
        z3 = fftshift(ifft(fftshift(conj(y3))));
        B = z3(ceil((npzf-npB)/2)+handles.NumberOfPoints:-1:ceil((npzf-npB)/2)+1);
        B = B*FBnomialScalingFactor;
        
        FIRnp = 4096;
        [h, ~] = freqz(B,1,FIRnp,'whole');  % Frequency response h to filter B calculated over FIRnp points                                   % Absolute value of h = absolute value
                                            % of pulse frequency profile. Only variable remaining is the phase,
                                            % which is expressed through the A polynomial.
end;

% Calculate A polynomial
absA = sqrt(1 - h.*conj(h));                                 % Eq. (17) from Pauly et al
A = absA.*exp(-1i*imag(hilbert(real(log(absA)),length(absA))));    % Eq. (18) from Pauly et al

% Inverse SLR Transform ******************
gamma = 42.57;      % Gamma for protons (kHz/mT)
PulseCounter = handles.NumberOfPoints;
PulseDwellTime = handles.PulseLength/handles.NumberOfPoints; % us
const = 2*pi*(gamma/2)*(PulseDwellTime/1000);

FB = ifft(h); FA = ifft(A);

while PulseCounter > 0
 
    % Angle between A and B - Eq. (16) in Pauly et al
	Theta(PulseCounter) = FB(1)/FA(1)/(1i*abs(FB(1)/FA(1)));

    % RF amplitude - Eq. (16) in Pauly et al
	B1(PulseCounter) = (Theta(PulseCounter)/const)*atan(abs(FB(1)/FA(1)));
	
    % Cosine and sine of B1 - Eq. (11) in Pauly et al
	C(PulseCounter) = cos(const*abs(B1(PulseCounter)));
	S(PulseCounter) = 1i*Theta(PulseCounter)*sin(const*abs(B1(PulseCounter)));
   
	FA1 = FA(1:end-1); FAN = FA(2:end);
	FB1 = FB(1:end-1); FBN = FB(2:end);
	
    % Recursive inverse SLR algorithm
	FA = C(PulseCounter)*FA1 + conj(S(PulseCounter))*FB1;    % Eq. (15) in Pauly et al
	FB = -S(PulseCounter)*FAN + C(PulseCounter)*FBN;         % Eq. (15) in Pauly et al

	PulseCounter = PulseCounter - 1;
end;

B1 = -imag(B1);
B1 = B1/max(abs(B1));

% Split calculate B1 field into RF amplitude and RF phase
RF = zeros(1,handles.NumberOfPoints);
phs = zeros(1,handles.NumberOfPoints);
for PulseCounter = 1:handles.NumberOfPoints;
   if B1(PulseCounter) < 0.0;
      RF(PulseCounter) = -B1(PulseCounter);
      phs(PulseCounter) = 180.0;
   else
      RF(PulseCounter) = B1(PulseCounter);
      phs(PulseCounter) = 0.0;
   end;
end;

freq = 0*phs;

switch handles.SLRPulsePhase
    case 'Maximum'
        % Switch RF pulse for maximum phase
        RF(end:-1:1) = RF;
        phs(end:-1:1) = phs;
end;

TimeResolution = handles.PulseLength/(handles.NumberOfPoints-1);
Time = 0:TimeResolution:handles.PulseLength;

 % Constant gradient modulation
 grad = 0.0*phs + 1.0;