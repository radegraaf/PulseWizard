function varargout = PulseWizard_RFGeneration(varargin)
% PULSEWIZARD_RFGENERATION MATLAB code for PulseWizard_RFGeneration.fig
%      PULSEWIZARD_RFGENERATION, by itself, creates a new PULSEWIZARD_RFGENERATION or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD_RFGENERATION returns the handle to a new PULSEWIZARD_RFGENERATION or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD_RFGENERATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD_RFGENERATION.M with the given input arguments.
%
%      PULSEWIZARD_RFGENERATION('Property','Value',...) creates a new PULSEWIZARD_RFGENERATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_RFGeneration_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_RFGeneration_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard_RFGeneration

% Last Modified by GUIDE v2.5 18-Jul-2018 15:54:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_RFGeneration_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_RFGeneration_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard_RFGeneration is made visible.
function PulseWizard_RFGeneration_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard_RFGeneration (see VARARGIN)

% Choose default command line output for PulseWizard_RFGeneration
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Set position of GUI based on screen dimensions
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .238*ScreenWidth;
FigYPos = .4898*ScreenHeight;
FigWidth = .3712*ScreenWidth;
FigHeight = .4103*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

% Initialize GUI values
Initialize_GUI(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_RFGeneration_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%**************************************************************************
% Code related to edit box for entering input file name
%**************************************************************************
function InputFile_Edit_Callback(hObject, eventdata, handles)
% Callback for edit box to enter the input RF pulse file. 
% This option is primarily used for generating multi-frequency RF pulses 
% from a base, single-frequency RF pulse.

% Assign updated filename to InputFile
handles.InputFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)

function InputFile_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box.
% Executes after setting all properties.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Set default pathway
set(hObject,'String',pwd);

% Assign default pathway to InputFile
handles.InputFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)


%**************************************************************************
% Code related to pulldown menu for selecting input file format
%**************************************************************************
function InputFileFormat_PullDownMenu_Callback(hObject, eventdata, handles)
% Callback for pulldown menu setting the file format of the RF pulse. 

InputFileFormat = cellstr(get(hObject,'String'));
handles.InputFileFormat = InputFileFormat{get(hObject,'Value')};

% Update GUI data structure
guidata(hObject,handles)

function InputFileFormat_PullDownMenu_CreateFcn(hObject, eventdata, handles)
% Creation function, executes after setting all properties.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to push button for selecting input file
%**************************************************************************
function SelectInputFile_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Select Input File button

% Prepare for when Cancel button is pressed
InputFileCancel = handles.InputFile;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select input file',handles.InputFile);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.InputFile = InputFileCancel;
else
    handles.InputFile = [pathname filename];
end;

% Updata GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.InputFile_Edit,'String',handles.InputFile);


%**************************************************************************
% Code related to push button for loading RF pulse
%**************************************************************************
function LoadRFPulse_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Load RF Pulse button

switch handles.InputFileFormat
    case {'PulseWizard','Bruker','Varian'}    
        % Load RF pulse from file
        [time, handles.RF handles.freq handles.phs handles.grad] = PulseWizard_RFGeneration_LoadRFPulse(handles);
              
        % Display RF pulse
        PulseWizard_RFPulse(time,handles.RF,handles.freq,handles.phs,handles.grad);
    case 'GE'
        errordlg('GE Input File Format Is Not Implemented','Error');
    case 'Philips'
        errordlg('Philips Input File Format Is Not Implemented','Error');
    case 'Siemens'
        errordlg('Siemens Input File Format Is Not Implemented','Error');
    otherwise
        errordlg('Select Input File Format Before Loading RF Pulse','Error');
end;

handles.NumberOfPoints = length(handles.RF);

% 3. Updata Number Of Points in main RF generation window
set(handles.NumberOfPoints_Edit,'String',handles.NumberOfPoints);

% Updata GUI data structure
guidata(hObject,handles)


%**************************************************************************
% Code related to edit box for entering output file name
%**************************************************************************
function OutputFile_Edit_Callback(hObject, eventdata, handles)
% Callback for edit box to enter the output RF pulse file. 

% Assign updated filename to OutputFile
handles.OutputFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)


function OutputFile_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box.
% Executes after setting all properties.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Set default pathway
set(hObject,'String',pwd);

% Assign default pathway to OutputFile
handles.OutputFile = get(hObject,'String');

% Updata GUI data structure
guidata(hObject,handles)


%**************************************************************************
% Code related to pulldown menu for selecting output file format
%**************************************************************************
function OutputFileFormat_PullDownMenu_Callback(hObject, eventdata, handles)
% Function executes on selection change in OutputFileFormat pulldown menu.

OutputFileFormat = cellstr(get(hObject,'String'));
handles.OutputFileFormat = OutputFileFormat{get(hObject,'Value')};

% Update GUI data structure
hObject = findall(0,'Name','PulseWizard_RFGeneration');
guidata(hObject,handles)

function OutputFileFormat_PullDownMenu_CreateFcn(hObject, eventdata, handles)
% Creation function, executes after setting all properties.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to push button for selecting output file
%**************************************************************************
function SelectOutputFile_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Select Output File button

% Prepare for when Cancel button is pressed
OutputFileCancel = handles.OutputFile;

% Get new file and path names
[filename, pathname] = uiputfile('*.*','Select output file',handles.OutputFile);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.OutputFile = OutputFileCancel;
else
    handles.OutputFile = [pathname filename];
end;

% Update GUI data structure
hObject = findall(0,'Name','PulseWizard_RFGeneration');
guidata(hObject,handles)

set(handles.OutputFile_Edit,'String',handles.OutputFile);


%**************************************************************************
% Code related to push button for saving RF pulse
%**************************************************************************
function SaveRFPulse_Push_Callback(hObject, eventdata, handles)
% Function executes when pushing the Save RF Pulse button

switch handles.OutputFileFormat
    case {'PulseWizard','Bruker','Varian'}
        PulseWizard_RFGeneration_SaveRFPulse(handles);
    case 'GE'
        errordlg('GE Output File Format Is Not Implemented','Error');
    case 'Philips'
        errordlg('Philips Output File Format Is Not Implemented','Error');
    case 'Siemens'
        errordlg('Siemens Output File Format Is Not Implemented','Error');
    otherwise
        errordlg('Select Output File Format Before Saving RF Pulse','Error');
end;


%**************************************************************************
% Code related to edit box for number of points in RF pulse
%**************************************************************************
function NumberOfPoints_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for NumberOfPoints
handles.NumberOfPoints = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.NumberOfPoints) > 0) || (isinf(handles.NumberOfPoints) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of points.'];
    ErrorMessage2 = ['Error: Number of points set to valid default value (1024).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.NumberOfPoints = 1024;
    set(hObject,'String',handles.NumberOfPoints);
end;

% Only allow positive integer numbers
if (rem(handles.NumberOfPoints,1) ~= 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of points.'];
    ErrorMessage2 = ['Error: Number of points set to valid default value (' num2str(abs(round(handles.NumberOfPoints))) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.NumberOfPoints = abs(round(handles.NumberOfPoints));
    set(hObject,'String',handles.NumberOfPoints);
end;

% Enforce a minimum of 2 points
if (handles.NumberOfPoints < 2)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of points.'];
    ErrorMessage2 = ['Error: Number of points set to valid default value (2).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.NumberOfPoints = 2;
    set(hObject,'String',handles.NumberOfPoints);
end;

% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated NumberOfPoints to the final, pulse-specific window
RFPulseFamily_PullDownMenu_Update(handles)

function NumberOfPoints_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for RF pulselength
%**************************************************************************
function PulseLength_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for PulseLength
handles.PulseLength = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.PulseLength) > 0) || (isinf(handles.PulseLength) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for pulse length.'];
    ErrorMessage2 = ['Error: Pulse length set to valid default value (5.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.PulseLength = 5.0;
    set(hObject,'String',handles.PulseLength);
end;

% Only allow positive pulse lengths
if (handles.PulseLength < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for pulse length.'];
    ErrorMessage2 = ['Error: Pulse length set to valid default value (' num2str(abs(handles.PulseLength)) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.PulseLength = abs(handles.PulseLength);
    set(hObject,'String',handles.PulseLength);
end;

% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated PulseLength to the final, pulse-specific window
RFPulseFamily_PullDownMenu_Update(handles)

function PulseLength_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
    

%**************************************************************************
% Code related to edit box for RF initial phase
%**************************************************************************
function InitialPhase_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for InitialPhase
handles.InitialPhase = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.InitialPhase) > 0) || (isinf(handles.InitialPhase) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for initial phase.'];
    ErrorMessage2 = ['Error: Initial phase set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.InitialPhase = 0.0;
    set(hObject,'String',handles.InitialPhase);
end;

% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated InitialPhase to the final, pulse-specific window
RFPulseFamily_PullDownMenu_Update(handles)

function InitialPhase_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to edit box for RF frequency offset
%**************************************************************************
function Frequency_Edit_Callback(hObject, eventdata, handles)
% Function executes when entering a new value for Frequency
handles.FrequencyOffset = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FrequencyOffset) > 0) || (isinf(handles.FrequencyOffset) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for frequency offset.'];
    ErrorMessage2 = ['Error: Frequency offset set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FrequencyOffset = 0.0;
    set(hObject,'String',handles.FrequencyOffset);
end;

% Updata GUI data structure
guidata(hObject,handles)

% Transfer the updated Frequency to the final, pulse-specific window
RFPulseFamily_PullDownMenu_Update(handles)

function Frequency_Edit_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%**************************************************************************
% Code related to pulldown menu to select RF pulse family
%**************************************************************************
function RFPulseFamily_PullDownMenu_Callback(hObject, eventdata, handles)
% Function executes when selecting a new RF pulse family
RFPulseFamily = cellstr(get(hObject,'String'));
handles.RFPulseFamilySelected = RFPulseFamily{get(hObject,'Value')};

switch handles.RFPulseFamilySelected
    case {'AFP','AHP','AM','BIR4','FOCI','RAHP','SLR'}
        % Parameters to be transferred to next RF generation subprogram
        varargin{1} = [handles.NumberOfPoints handles.PulseLength handles.FrequencyOffset handles.InitialPhase];
        varargin{2} = handles.RFPulseFamilySelected;
        varargin{3} = 'Yes';    % Initialize next window
        
    case 'Multi-frequency'
        % Parameters to be transferred to next RF generation subprogram
        varargin{1} = [handles.NumberOfPoints handles.PulseLength handles.FrequencyOffset handles.InitialPhase];
        varargin{2} = handles.RFPulseFamilySelected;
        varargin{3} = handles.RF;
        varargin{4} = handles.phs;
        varargin{5} = handles.grad;
        varargin{6} = 'Yes';    % Initialize next window
end;
 
% Upon pulldown selection, open a new window with
% parameter entries specific for the new RF pulse family.
switch handles.RFPulseFamilySelected
    case 'AFP'
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_AFP');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_AFP(varargin);
        else
            varargin{3} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_AFP(varargin);
        end;
        
    case 'AHP'
        % AHP pulse is taken as the first half of the corresponding AFP pulse
        
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_AFP');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_AFP(varargin);
        else
            varargin{3} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_AFP(varargin);
        end;
        
    case 'AM'      
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_AM');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_AM(varargin);
        else
            varargin{3} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_AM(varargin);
        end;

     case 'BIR4'        
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_BIR4');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_BIR4(varargin);
        else
            varargin{3} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_BIR4(varargin);
        end;
        
     case 'FOCI'        
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_FOCI');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_FOCI(varargin);
        else
            varargin{3} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_FOCI(varargin);
        end;
        
    case 'Multi-frequency'
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_MF');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_MF(varargin);
        else
            varargin{6} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_MF(varargin);
        end;
        
    case 'RAHP'
        % Reversed AHP pulse is taken as the second half of the corresponding AFP pulse
        
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_AFP');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_AFP(varargin);
        else
            varargin{3} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_AFP(varargin);
        end;
        
     case 'SLR'        
        % If the pulse specific window does not exist, initialize
        % parameters. Otherwise, skip initialization.
        hh = findall(0,'Name','PulseWizard_RFGeneration_SLR');
        if (isempty(hh) > 0)
            PulseWizard_RFGeneration_SLR(varargin);
        else
            varargin{3} = 'No';     % Do not initialize next window
            PulseWizard_RFGeneration_SLR(varargin);
        end;
end;

% Update GUI data structure
guidata(hObject, handles);

CloseWindowsFromPreviousSimulations(handles)

function RFPulseFamily_PullDownMenu_CreateFcn(hObject, eventdata, handles)
% Create function for edit box, executes after setting all properties
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function RFPulseFamily_PullDownMenu_Update(handles)
% Function executes on new parameter entries in the general
% RF generation window to ensure that those new entries are 
% transferred to the RF pulse specific parameter window.

% Parameters to be transferred to next RF generation subprogram
varargin{1} = [handles.NumberOfPoints handles.PulseLength handles.FrequencyOffset handles.InitialPhase];
varargin{2} = handles.RFPulseFamilySelected;
varargin{3} = handles.RF;
varargin{4} = handles.phs;
varargin{5} = handles.grad;
varargin{6} = 'No';    % Do not initialize next window
 
switch handles.RFPulseFamilySelected
    case {'AFP','AHP','RAHP'}
        PulseWizard_RFGeneration_AFP(varargin);
    case 'AM'
        PulseWizard_RFGeneration_AM(varargin);
    case 'BIR4'
        PulseWizard_RFGeneration_BIR4(varargin);
    case 'FOCI'
        PulseWizard_RFGeneration_FOCI(varargin);
    case 'Multi-frequency'
        PulseWizard_RFGeneration_MF(varargin);
    case 'SLR'
        PulseWizard_RFGeneration_SLR(varargin);
end;


%**************************************************************************
% Code related to GUI/handles parameter initialization
%**************************************************************************
function Initialize_GUI(hObject, handles)

handles.InputFileFormat = 'Input File Format';
handles.InputFile = pwd;
handles.OutputFileFormat = 'Output File Format';
handles.OutputFile = pwd;
handles.RFPulseFamilySelected = 'RF Pulse Family';
handles.NumberOfPoints = 1024;
handles.PulseLength = 5.0;
handles.FrequencyOffset = 0;
handles.InitialPhase = 0;
handles.RF = [0 0];
handles.phs = [0 0];
handles.grad = [0 0];

% Update GUI data structure
guidata(hObject, handles);

% --- Executes on button press in HelpManual_PushButton.
function HelpManual_PushButton_Callback(hObject, eventdata, handles)
% hObject    handle to HelpManual_PushButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

HelpFile = [pwd '\PulseWizard_Manual.pdf'];

[~, result] = system(HelpFile);

if (isempty(result) < 1)
    errordlg({'     PulseWizard Manual Could Not Be Opened.',' ',...
        'Manual PDF File Is Located In PulseWizard Directory'},'File Error');
end;

function CloseWindowsFromPreviousSimulations(handles)

switch handles.RFPulseFamilySelected
    case {'AFP','AHP','RAHP'}
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AM');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
 
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_BIR4');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;

        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_FOCI');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_SLR');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
    case 'AM'
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AFP');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
 
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_BIR4');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;

        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_FOCI');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_SLR');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;    
        
     case 'BIR4'
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AFP');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
 
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AM');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;

        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_FOCI');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_SLR');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
      case 'FOCI'
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AFP');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
 
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AM');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;

        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_BIR4');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_SLR');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
      case 'SLR'
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AFP');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
 
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_AM');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;

        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_BIR4');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;
        
        hObject1 = findall(0,'Name','PulseWizard_RFGeneration_FOCI');
        if (isempty(hObject1) < 1)
            delete(hObject1);
        end;  
end;
