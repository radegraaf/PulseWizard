function [Time, RF, freq, phs, grad] = PulseWizard_RFGeneration_CalculateBIR4(handles)

%**************************************************************************
% Function for the calculation of BIR4 RF pulses based on a range of 
% RF and frequency/phase modulation functions.
%
% Notes:
% 1. Number of points for BIR4 pulses refers to points per AHP segment.
% 2. RF and phase modulations are forced to be time-symmetric.
%
% Original by Robin A. de Graaf, October 2016
%**************************************************************************
TimeResolution = handles.PulseLength/(4*handles.NumberOfPoints-1);
Time = 0:TimeResolution:handles.PulseLength;

switch handles.BIR4Modulation
    case 'sech/tanh'
        %******************************************************************
        % BIR4 pulses based on 'hyperbolic secant' sech/tanh/tan modulation.
        %
        % Original/relevant publications:
        % 1. M. Garwood, Y. Ke,
        %    J. Magn. Reson. 94, 511-525 (1991)
        % 2. R. A. de Graaf, Y. Luo, M. Garwood, K. Nicolay,
        %    J. Magn. Reson. 113B, 35-45 (1996)
        %
        % See also Chapter 5 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from 0 to +1
        TimeApp = 0:1/(handles.NumberOfPoints-1):1;
        
        % RF modulation (first segment)
        RF(1:handles.NumberOfPoints) = sech(handles.RFConstant1*TimeApp);
        % Normalize RF modulation to 0 to +1 range
        RF = RF/max(RF);
        
        % Frequency modulation
        freq = tanh(handles.RFConstant2*TimeApp);

        % Scale frequency modulation to full BandWidth
        freq = (handles.BandWidth/2.0)*freq;
        
        % Phase modulation = time integral of frequency
        phs = 360*cumsum(freq*TimeResolution);
        % Force first point in phase modulation to zero
        phs = phs - phs(1);
        
        % Calculate second segment of pulse based on symmetry
        RF(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = RF(handles.NumberOfPoints:-1:1);
        freq(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = -1.0*freq(handles.NumberOfPoints:-1:1);
        phs(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = phs(handles.NumberOfPoints:-1:1) + 180 + handles.RFConstant3/2.0;
        
        % Calculate second half of pulse based on symmetry
        RF(2*handles.NumberOfPoints+1:4*handles.NumberOfPoints) = RF(2*handles.NumberOfPoints:-1:1);
        freq(2*handles.NumberOfPoints+1:4*handles.NumberOfPoints) = -1.0*freq(2*handles.NumberOfPoints:-1:1);
        phs(2*handles.NumberOfPoints+1:4*handles.NumberOfPoints) = phs(2*handles.NumberOfPoints:-1:1); 
        
        % Add frequency offset to frequency modulation
        freq = freq + handles.FrequencyOffset;
        
        % Add frequency offset as a phase ramp to phase modulation
        phs = phs + 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
        
    case 'tanh/tan'
        %******************************************************************
        % BIR4 pulses based on tanh/tan modulation that closely reflect 
        % numerically optimized modulation (NOM) functions.
        %
        % Original/relevant publications:
        % 1. M. Garwood, Y. Ke,
        %    J. Magn. Reson. 94, 511-525 (1991)
        % 2. K. Ugurbil, M. Garwood, A. Rath,
        %    J. Magn. Reson. 80, 448-469 (1988)
        %
        % See also Chapter 5 in 'In Vivo NMR spectroscopy' book.
        %******************************************************************
        
        % Define apparent time, running from 0 to +1
        TimeApp = 0:1/(handles.NumberOfPoints-1):1;
        
        % RF modulation (first segment)       
        RF(1:handles.NumberOfPoints) = tanh(handles.RFConstant1*(1.0 - TimeApp));
        
        % Frequency modulation (first segment)
        freq(1:handles.NumberOfPoints) = tan(handles.RFConstant2*TimeApp);
        
        % Normalize frequency modulation to 0 to +1 range
        freq = freq/max(freq);
        % Scale frequency modulation to full BandWidth
        freq = (handles.BandWidth/2.0)*freq;
        
        % Phase modulation = time integral of frequency
        phs = 360*cumsum(freq*TimeResolution);
        % Force first point in phase modulation to zero
        phs = phs - phs(1);      
        
        % Calculate second segment of pulse based on symmetry
        RF(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = RF(handles.NumberOfPoints:-1:1);
        freq(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = -1.0*freq(handles.NumberOfPoints:-1:1);
        phs(handles.NumberOfPoints+1:2*handles.NumberOfPoints) = phs(handles.NumberOfPoints:-1:1) + 180 + handles.RFConstant3/2.0;        
        
        % Calculate second half of pulse based on symmetry
        RF(2*handles.NumberOfPoints+1:4*handles.NumberOfPoints) = RF(2*handles.NumberOfPoints:-1:1);
        freq(2*handles.NumberOfPoints+1:4*handles.NumberOfPoints) = -1.0*freq(2*handles.NumberOfPoints:-1:1);
        phs(2*handles.NumberOfPoints+1:4*handles.NumberOfPoints) = phs(2*handles.NumberOfPoints:-1:1);        
        
        % Add frequency offset to frequency modulation
        freq = freq + handles.FrequencyOffset;
        
        % Add frequency offset as a phase ramp to phase modulation
        phs = phs + 360*handles.FrequencyOffset*Time;
        
        % Add initial phase offset
        phs = phs + handles.InitialPhase;
 end;
 
  % Constant gradient modulation
 grad = 0.0*phs + 1.0;