function varargout = PulseWizard(varargin)
% PULSEWIZARD MATLAB code for PulseWizard.fig
%      PULSEWIZARD, by itself, creates a new PULSEWIZARD or raises the existing
%      singleton*.
%
%      H = PULSEWIZARD returns the handle to a new PULSEWIZARD or the handle to
%      the existing singleton*.
%
%      PULSEWIZARD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PULSEWIZARD.M with the given input arguments.
%
%      PULSEWIZARD('Property','Value',...) creates a new PULSEWIZARD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PulseWizard_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PulseWizard_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PulseWizard

% Last Modified by GUIDE v2.5 04-Jun-2018 17:18:26

addpath(genpath(pwd));

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PulseWizard_OpeningFcn, ...
                   'gui_OutputFcn',  @PulseWizard_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PulseWizard is made visible.
function PulseWizard_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PulseWizard (see VARARGIN)

% Choose default command line output for PulseWizard
handles.output = hObject;

set(handles.Exit_PushButton,'TooltipString','Closes all windows except the main PulseWizard window');

% Set Position/Size of Figure Based on Screen Size
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .02*ScreenWidth;
FigYPos = .2275*ScreenHeight;
FigWidth = .21*ScreenWidth;
FigHeight = .6725*ScreenHeight;

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight])

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = PulseWizard_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function RFPulseGeneration_PushButton_Callback(hObject, eventdata, handles)
% Function executes on RF Generation button push.

% Check if windows associated with RF generation and RF simulation
% are open before closing them.
Exit_PushButton_Callback; 

% Start main RF generation GUI
PulseWizard_RFGeneration;

function RFPulseSimulation_PushButton_Callback(hObject, eventdata, handles)
% Function executes on RF Simulation button push.

% Check if windows associated with RF generation and RF simulation
% are open before closing them.
Exit_PushButton_Callback; 

% Start main RF simulation GUI
PulseWizard_RFSimulation;

function Exit_PushButton_Callback(hObject, eventdata, handles)
% Function executes on Exit button push.

% Check if windows associated with RF generation are present before closing them
hObject = findall(0,'Name','PulseWizard_RFPulse');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFGeneration_AM');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFGeneration_AFP');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFGeneration_BIR4');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFGeneration_FOCI');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFGeneration_MF');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFGeneration_SLR');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFGeneration');
if (isempty(hObject) < 1)
    delete(hObject);
end;

% Check if windows associated with RF simulation are present before closing them
hObject = findall(0,'Name','PulseWizard_RFSimulation_Results_M_RF');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_RF');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_RF');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Freq');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_Freq');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Pos');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Results_RC_Pos');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Results_M_Time');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Freq');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Pos');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation_Time');
if (isempty(hObject) < 1)
    delete(hObject);
end;

hObject = findall(0,'Name','PulseWizard_RFSimulation');
if (isempty(hObject) < 1)
    delete(hObject);
end;
